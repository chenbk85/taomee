/**
 * =====================================================================================
 *
 * @file  test.cpp
 *
 * @brief 
 *
 * compiler  GCC4.1.2
 * platform  Linux
 *
 * copyright:  TaoMee, Inc. ShangHai CN. All rights reserved.
 * 		
 * ------------------------------------------------------------
 * 	note: set tabspace=4 
 *
 * =====================================================================================
 */

#include <cstdlib>
#include <ctime>

#include <algorithm>
#include <iostream>
#include <iterator>

#include "astar.hpp"

using namespace std;
using namespace taomee;

int main()
{
	AStar<> astar("1000101.txt");
	if (!astar) {
		cout << "oops" << endl;
		return 0;
	}
	cout << "fine" << endl;

	srand(time(0));

	const AStar<>::Points* pts = astar.findpath(AStar<>::Point(350, 210), AStar<>::Point(160, 0));
	for (AStar<>::Points::const_iterator it = pts->begin(); it != pts->end(); ++it) {
		cout << '(' << it->x << ", " << it->y << ')' << ", ";
	}
	cout << endl;
	//copy(pts->begin(), pts->end(), ostream_iterator<string>(outfile, "\n") );
	return 0;
}
