// g++ event_test.cpp -lglib-2.0 -ltaomee++ -I/usr/include/glib-2.0 -I/usr/lib/glib-2.0/include/

#include <libtaomee++/event/event_mgr.hpp>

using namespace taomee;

#include <iostream>

using namespace std;

#include <sys/time.h>

class A : public EventableObject {
public:
	int a(int& cnt, int& id)
	{
		cout << "a: " << id << endl;
		if (--cnt == 0) {
			return -1;
		}
		return 0;
	}
};

EventMgr emgr;

int main()
{
	A* a = new A;
	timeval tv;
	gettimeofday(&tv, 0);
	tv.tv_sec += 1;
	TimedEvent* ev1 = emgr.add_event(*a, &A::a, 4, 1, tv, 1000, -1);
	tv.tv_sec += 1;
	TimedEvent* ev2 = emgr.add_event(*a, &A::a, 2, 2, tv, 1000, -1);
	tv.tv_sec += 1;
	TimedEvent* ev3 = emgr.add_event(*a, &A::a, 2, 3, tv, 1000, -1);

	emgr.modify_expired_tv(ev1, tv);
	emgr.modify_interval(ev3, 2000);
	emgr.remove_event(ev2);

	for (int i = 0; i != 200; ++i) {
		emgr.process_events();
		usleep(100000);
	}
	
	delete a;
}

