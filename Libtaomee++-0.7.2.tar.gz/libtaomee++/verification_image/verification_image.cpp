#include <cassert>

#include <libtaomee++/random/random.hpp>
#include <libtaomee++/utils/utilities.hpp>

using namespace std;
using namespace taomee;

extern "C" {
#include <dirent.h>

#include <gd.h>

#include <libtaomee/utils.h>
}

#include "verification_image.hpp"

namespace taomee {

const char VerificationImageGenerator::sm_simple_meta_chars[] = "123456789";
const char VerificationImageGenerator::sm_meta_chars[] = "abcdeghjkmnpqrstuwxyzABCDEGHJKLMNPQRSTUWXYZ2345689";
const char VerificationImageGenerator:: sm_thin_meta_chars[] = "abcdeghjknpqrstuxyzABCEHJKLPSTUXYZ2345689";
const double VerificationImageGenerator::sm_angles[] = { -0.4, -0.35, -0.28, -0.15, 0.15, 0.25, 0.30, 0.4 };

VerificationImageGenerator::
VerificationImageGenerator(const char* font_dir, int length, int width, int fontsize)
	: cm_length(length), cm_width(width), cm_fontsize(fontsize)
{
	assert(fontsize > 0);

	DIR* dir = opendir(font_dir);
	if (dir == 0) {
		throw VerifImgError("Invalid directory!");
	}

	dirent* dentry;
	while ((dentry = readdir(dir))) {
		if (is_valid_ttf(dentry->d_name)) {
			m_fontpath.push_back(string(font_dir) + "/" + dentry->d_name);
		}
	}

	srand(time(0));
}

VerificationImage VerificationImageGenerator::
generate(int nchars, bool is_easy)
{
	if ((nchars < 3) || (nchars > sc_verif_code_num)) {
		throw VerifImgError("Invalid number of characters for verification!");  
	}

	// randomly generate verification code
	char verif_code[sc_verif_code_num + 1];
	bool isthick = false;
	for (int i = 0; i != nchars; ++i) {
		if (is_easy) {
			verif_code[i] = sm_simple_meta_chars[ranged_random(0, array_elem_num(sm_simple_meta_chars) - 2)];
		} else{
			verif_code[i] = sm_meta_chars[ranged_random(0, array_elem_num(sm_meta_chars) - 2)];
		}

		//prevent use too much fat chars 
		if (isthick && (verif_code[i] == 'M' || verif_code[i] == 'W' || verif_code[i] == 'm' 
				|| verif_code[i] == 'G' || verif_code[i] == 'Q')) {
			verif_code[i] = sm_thin_meta_chars[ranged_random(0, array_elem_num(sm_thin_meta_chars) - 2)];
		}

		if (verif_code[i] == 'M' || verif_code[i] == 'W' || verif_code[i] == 'm' 
				|| verif_code[i] == 'G' || verif_code[i] == 'Q') {
			isthick = true;
		}
	}
	verif_code[nchars] = '\0';

	// obtain brect so that we can size the image
	int brect[8];
	char* fontpath = const_cast<char*>(m_fontpath[rand() % m_fontpath.size()].c_str());
	double angle = sm_angles[rand() % array_elem_num(sm_angles)];
	const char* err = gdImageStringFT(0, brect, 0, fontpath, cm_fontsize, angle, 0, 0, verif_code);
	if (err != 0) {
		throw VerifImgError(string("gdImageStringFT: ") + err);
	}

	gdImagePtr im = gdImageCreate(cm_length, cm_width);
	if (im == 0) {
		throw VerifImgError("Failed to create image!");
	}

	// Background color (first allocated)
	gdImageColorResolve(im, 243, 254, 236);

	//font color
	int color = gdImageColorResolve(im, ranged_random(0, 100), ranged_random(0, 150), ranged_random(0, 200));

	//generate the elements
	if (is_easy) {
		simple_noisy(im, color);
    } else{
		complicated_noisy(im);
	}
	
	/* render the string, offset origin to center string*/
	/* note that we use top-left coordinate for adjustment
	* since gd origin is in top-left with y increasing downwards. */
	char single_code[2] = { 0 };

	int x, y;

	if (is_easy) {
		x = ranged_random(4, 7) - brect[6];
		y = ranged_random(3, 5)- brect[7];
	} else {
		x = 4;
		y = ranged_random(1, 4) - brect[7];
	}

	int start_point;
	double step = (cm_length - 5.0) / nchars;
	for (int i = 0; i < nchars; i++) {
		single_code[0] = verif_code[i];
	
		double angle = sm_angles[rand() % array_elem_num(sm_angles)];

		if (i == 0)	{
			angle = -ranged_random(0, 6) / 10.0;
		} else if (i == nchars - 1) {
			angle = ranged_random(0, 6) / 10.0;
		}
		err = gdImageStringFT(im, 0, color, fontpath, cm_fontsize, angle, x, y, single_code);
		if (err != 0) {
			gdImageDestroy(im); // Destroy it
			throw VerifImgError(string("gdImageStringFT: ") + err);
		}

		if (is_easy) {
			start_point = ranged_random(4, 5) - brect[6];
			x = int((start_point + step * (i + 1)) - ranged_random(0, 1));
			y = ranged_random(3, 5)- brect[7];
		} else {
			x = int((x + step) - ranged_random(0, 1));
			y = ranged_random(2, 4)- brect[7];
			color = gdImageColorResolve(im, ranged_random(0, 100), ranged_random(0, 150), ranged_random(0, 200));
		}
		
	}

	// generate a verification image object
	int img_size;
	char* img = reinterpret_cast<char*>(gdImagePngPtr(im, &img_size));
	VerificationImage image(verif_code, img, img_size);

	/* Destroy it */
	gdFree(img);
	gdImageDestroy(im);

	return image;
}

void VerificationImageGenerator::
simple_noisy(gdImagePtr im, int color)
{	
	// noisy lines
    gdPoint points[5];
	for (int i = 0; i < 5; ++i) {
		points[i].x = ranged_random(0, cm_length);
	    points[i].y = ranged_random(0, cm_width);
	}
    points[2].x = cm_length/2;   
    points[2].y = cm_width/2;

	int white = gdImageColorResolve(im, ranged_random(150, 250), ranged_random(150, 220), ranged_random(150, 200));  

	gdImageFilledPolygon(im, points, 3, white); 
    gdImagePolygon(im, points, 5, color);
}

void VerificationImageGenerator::
complicated_noisy(gdImagePtr im)
{
	// noisy lines
	for (int i = 0; i != 5; ++i) {
		int color = gdImageColorResolve(im, ranged_random(0, 100), ranged_random(0, 150), ranged_random(0, 200));
		int x1 = ranged_random(0, cm_length);
		int y1 = ranged_random(0, cm_width);
		int x2 = ranged_random(0, cm_length);
		int y2 = ranged_random(0, cm_width);
		int arc_s = rand() % 180;
		int arc_e = rand() % 180 + arc_s;

		gdImageLine(im, x1, y1, x2, y2, color);
		gdImageArc(im, x1 + 1, y1 + 1, x2 - x1, y2 - y1, arc_s, arc_e, color);
	}
	// noisy points
	for (int i = 0; i != 60; ++i) {
		int color = gdImageColorResolve(im, ranged_random(0, 100), ranged_random(0, 150), ranged_random(0, 200));
		int x1 = ranged_random(0, cm_length);
		int y1 = ranged_random(0, cm_width);
		gdImageSetPixel(im, x1, y1, color);
	}
}




bool VerificationImageGenerator::
is_valid_ttf(const char* filename)
{
	return (check_filename_ext(filename, "ttf") || check_filename_ext(filename, "ttc"));
}

}

