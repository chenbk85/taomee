#include <algorithm>
#include <fstream>
#include <vector>

#include "ini_parser.hpp"

using namespace std;

namespace taomee {

class IniAnalyzer {
public:
	IniAnalyzer(StrMap& strmap) : ini_map_(strmap)
		{ }
	void operator()(const string& strini);
private:
	string   sect_;
	StrMap&  ini_map_;
};

void IniAnalyzer::
operator()(const std::string& strini)
{
	string::size_type first = strini.find('[');
	string::size_type last  = strini.rfind(']');
	// if neither "[" nor "]" exists
	if ((first == string::npos) && (last == string::npos)) {
		if(sect_.empty()) {
			return;
		}

		first = strini.find('=');
		if (first == string::npos) {
			return;
		}

		string strtmp1(strini, 0, first);
		string strtmp2(strini, first + 1, string::npos); // copy the rest characters to strtmp2

		first = strtmp1.find_first_not_of(" \t");
		last  = strtmp1.find_last_not_of(" \t");
		if((first == string::npos) || (last == string::npos)) {
			return;
		}
		std::string strkey(strtmp1, first, last - first + 1);

		string::size_type tmp;
		last = strtmp2.find("#");
		tmp  = strtmp2.find("//");
		if (tmp < last) {
			last = tmp;
		}
		strtmp2 = strtmp2.substr(0, last);

		first = strtmp2.find_first_not_of(" \t");
		last  = strtmp2.find_last_not_of(" \t");
		if ((first == string::npos) || (last == string::npos)) {
			return;
		}

		ini_map_[sect_ + midstring + strkey] = strtmp2.substr(first, last - first + 1);
		return;
	}

	// if both "[" and "]" exist and in the form of "[xxx]"
	if ((first != string::npos) && (last != string::npos) && (first < (last - 1))) {
		sect_ = strini.substr(first + 1, last - first - 1);
	}
}


//--------------------------------------------------------
//  Implementation of IniParser
//--------------------------------------------------------
void IniParser::parse()
{
	std::ifstream fin(ini_path_.c_str());
	if (!fin) {
		throw IniParseError(std::string("Fail to Open File ") + ini_path_);
	}

	std::string inbuf;
	std::vector<std::string> strvect;
	while (std::getline(fin, inbuf)) {
		if (inbuf[inbuf.size() - 1] == '\r') {
			strvect.push_back(inbuf.substr(0, inbuf.size() - 1));
		} else {
			strvect.push_back(inbuf);
		}
	}

	for_each(strvect.begin(), strvect.end(), IniAnalyzer(ini_map_));
}

} // end of namespace taomee

