#!/bin/bash

sudo make 2>/dev/null
