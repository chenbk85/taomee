#include <cerrno>
#include <cstdlib>
#include <iostream>

extern "C" {
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <libtaomee/inet/tcp.h>
}

#include <libtaomee++/ev/eventpoll.hpp>

using namespace taomee;
using namespace std;

class Plugin {
public:
    void process()
        { }
};

EventPoll ep(50000);
Plugin plugin;

int file_fd[50000];

void on_acceptable(int fd);
void on_readable(int fd);
void on_writable(int fd);

int main(int argc, char* argv[])
{
	daemon(1, 1);

	int listenfd = safe_socket_listen(argv[1], atoi(argv[2]), SOCK_STREAM);
	if (listenfd != -1) {
		//set nonblock
		set_io_blockability(listenfd, 1);

		int bufsize = 16 * 1024;
		setsockopt(listenfd, SOL_SOCKET, SO_RCVBUF, (char *)&bufsize, sizeof(int));
		setsockopt(listenfd, SOL_SOCKET, SO_SNDBUF, (char *)&bufsize, sizeof(int));

		ep.add(listenfd, EventPoll::event_in, on_acceptable, 0);
		ep.add_plugin(plugin, &Plugin::process);
		ep.dispatch();
	}

	return 0;
}

void on_acceptable(int fd)
{
	for ( ; ; ) {
		struct sockaddr_in peer;
		int newfd = safe_tcp_accept(fd, &peer, 1);
		if (newfd != -1) {
			ep.add(newfd, EventPoll::event_in, on_readable, on_writable);
			
			char name[20];
			sprintf(name, "%d", newfd);
			file_fd[newfd] = open(name, O_CREAT | O_APPEND | O_WRONLY, 0755);
			continue;
		} else if ((errno == EMFILE) || (errno == ENFILE)) {
			ep.report_again_in(fd);
		}

		break;
	}
}

void on_readable(int fd)
{
	char buf[8196];
	int n = read(fd, buf, 8196);
	if (n == -1) {
        return;
    }

	if (n == 0) {
		ep.remove(fd);
		close(fd);
		close(file_fd[fd]);
		return;
	}

	if (n == 8196) {
		ep.report_again_in(fd);
	}

	write(file_fd[fd], buf, n);
}

void on_writable(int fd)
{
}
