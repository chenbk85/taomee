﻿libtaomee++安装指南

1. 把代码checkout到命名为libtaomee++的子目录下。
2. 进入libtaomee++子目录，运行INSTALL安装脚本，需要有sudo或者root权限。
3. 安装完毕。
4. samples目录下有一些使用实例。

依赖库
1. libxml2以上版本
2. libgd2以上版本
3. libtaomee
4. AsyncServer头文件

libtaomee++使用指南

1. 程序示例（a.cpp）

#include <iostream>

using namespace std;

#include <libtaomee++/conf_parser/ini_parser.hpp>

using namespace taomee;

int main()
{
    IniParser parser("./a.ini");
    parser.parse();
    cout << parser.read("test_str", "str") << endl
         << parser.read_int("test_int", "int") << endl;
}

2. a.ini文件
[test_str]
str = abcd // 注释   

[test_int]
int = -10  #  也是注释

3. 编译

g++ a.cpp -Wall -ltaomee++

4. 运行

./a.out 
abcd
-10
