/**
 *============================================================
 *  @file      file_desc.hpp
 *  @brief    TODO
 * 
 *  compiler   gcc4.1.2
 *  platform   Linux
 *
 *  copyright:  TaoMee, Inc. ShangHai CN. All rights reserved.
 *
 *============================================================
 */

#ifndef FILE_DESCRIPTOR_HPP_
#define FILE_DESCRIPTOR_HPP_

#include <cerrno>

extern "C" {
#include <unistd.h>
}

#include <libtaomee++/utils/noncopyable.hpp>

namespace taomee {

/**
  * @brief TODO
  */
class FileDescriptor : Noncopyable {
public:
	virtual ~FileDescriptor()
	{
		close(m_fd);
	}

	/*	
	1. When reading from a regular file, if the end of file is reached before the requested number of bytes has been read.
	    For example, if 30 bytes remain until the end of file and we try to read 100 bytes, read returns 30. The next time
	    we call read, it will return 0 (end of file).	
	2. When reading from a terminal device. Normally, up to one line is read at a time. (We'll see how to change this in
	    Chapter 18.)	
	3. When reading from a network. Buffering within the network may cause less than the requested amount to be returned.	
	4. When reading from a pipe or FIFO. If the pipe contains fewer bytes than requested, read will return only what is available.	
	5. When reading from a record-oriented device. Some record-oriented devices, such as magnetic tape, can return
	    up to a single record at a time.	
	6. When interrupted by a signal and a partial amount of data has already been read. We discuss this further in Section 10.5.	
	*/
	ssize_t read(void* buf, size_t nbytes);

	/*
	The return value is usually equal to the nbytes argument; otherwise, an error has occurred. A common cause for a
	write error is either filling up a disk or exceeding the file size limit for a given process.	
	For a regular file, the write starts at the file's current offset. If the O_APPEND option was specified when the file
	was opened, the file's offset is set to the current end of file before each write operation. After a successful write,
	the file's offset is incremented by the number of bytes actually written.	
	On  success, the number of bytes written is returned (zero indicates nothing was written).  On error, -1 is returned,
	and errno is set appropriately.
      If count is zero and fd refers to a regular file, then write() may return a failure status if one of the errors is detected.
      If  no  errors  are  detected,  0 will be returned without causing any other effect.  If count is zero and fd refers to a
      file other than a regular file, the results are not specified.
	*/
	ssize_t write(const void* buf, size_t nbytes);

protected:
	FileDescriptor()
	{
		m_fd = -1;
	}

protected:
	/*! file descriptor */
	int m_fd;
};

}

#endif // FILE_DESCRIPTOR_HPP_

