#include "file_desc.hpp"

namespace taomee {


ssize_t FileDescriptor::read(void* buf, size_t nbytes)
{
	ssize_t n;
	for ( ; ; ) {
		n = ::read(m_fd, buf, nbytes);
		if ((n != -1) || (errno != EINTR)) {
			break;
		} else {
			continue;
		}
	}

	return n;
}

ssize_t FileDescriptor::write(const void* buf, size_t nbytes)
{
	ssize_t n;
	for ( ; ; ) {
		n = ::write(m_fd, buf, nbytes);
		if ((n != -1) || (errno != EINTR)) {
			break;
		} else {
			continue;
		}
	}

	return n;
}


}

