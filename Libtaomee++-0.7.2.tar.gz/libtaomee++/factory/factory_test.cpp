#include <iostream>
#include <string>

#include "factory.hpp"

using namespace std;
using namespace taomee;

class P {
public:
    virtual void p() = 0;
};

class P1 : public P {
public:
    P1(void*) { }
    void p() { cout << "P1" << endl; }
};

class P2 : public P {
public:
    P2(void*) { }
    void p() { cout << "P2" << endl; }
};

class P3 : public P {
public:
    P3(void*) { }
    void p() { cout << "P3" << endl; }
};

int main()
{
    FactoryHolder<int, P> holder;

    holder.add_factory<P1>(1);
    holder.add_factory<P2>(2);
    holder.add_factory<P2>(3);
    holder.add_factory<P3>(3, true);

    holder.get_factory(1)->create()->p();
    holder.get_factory(2)->create()->p();
    holder.get_factory(3)->create()->p();

    cout << "----------" << endl;

    holder.remove_factory(3);
    holder.get_factory(1)->create()->p();
    holder.get_factory(2)->create()->p();
//  holder.get_factory(3)->create()->p();
}
