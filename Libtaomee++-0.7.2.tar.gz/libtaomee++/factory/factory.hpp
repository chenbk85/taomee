/**
 *============================================================
 *  @file      factory.hpp
 *  @brief     FactoryHolder用于保存继承于同一父类的所有工厂。\n
 *             具体用法请参考http://10.1.1.5/libtaomee++/samples/factory。
 *  
 *  compiler   gcc4.1.2
 *  platform   Linux
 *
 *  copyright:  TaoMee, Inc. ShangHai CN. All rights reserved.
 *
 *============================================================
 */

#ifndef LIBTAOMEEPP_FACTORY_HPP_
#define LIBTAOMEEPP_FACTORY_HPP_

#include <libtaomee++/utils/noncopyable.hpp>
#include <libtaomee++/utils/obj_registry.hpp>

namespace taomee {

/**
 * @brief FactoryHolder用于保存继承于同一父类的所有工厂。\n
 *        KeyType：键的类型，一个键可以唯一确定一个工厂。\n
 *        AbstractProdType：工厂所生产出来的产品的基类。所有产品必须都要有一个接收“void*”参数的构造函数，
 *                          例如“AbsProd(void* data);”。
 */
template <typename KeyType, typename AbstractProdType>
class FactoryHolder {
private:
	/**
	 * @brief 工厂父类
	 */
	class AbstractFactory {
	public:
		/**
		 * @brief 虚析构函数
		 */
		virtual ~AbstractFactory()
			{ }
		/**
		 * @brief 抽象的制造产品方法
		 */
		virtual AbstractProdType* create(void* data = 0) const = 0;
	};

public:
	/**
	 * @brief 具体的工厂，制造ProdType类型的产品，ProdType必须继承于AbstractProdType。
	 */
	template <typename ProdType>
	class Factory : public AbstractFactory {
	public:
		~Factory()
			{ }
		/**
		 * @brief 具体的制造产品方法，调用产品的Prod(void*)构造函数来创建一个具体的产品对象。
		 * @return 成功则返回new出来的产品对象的指针，失败则抛出std::bad_alloc异常。
		 * @note 当产品不再被使用时，必须调用delete将其释放。
		 */
		ProdType* create(void* data = 0) const
			{ return new ProdType(data); }
	};

public:
	/**
	 * @brief 添加一个工厂。\n
	 *        ProdType：工厂制造的产品的类型，必须继承于AbstractProdType。
	 * @param key 工厂的键，通过这个键可以唯一确定一个工厂
	 * @param override 是否覆盖键相同的工厂，默认是false不覆盖。
	 *                 如果选择不覆盖，则当键已存在时，插入失败，返回false。
	 *                 如果选择覆盖，则当键已存在时，把老的工厂删掉，插入新的工厂，并且返回true。
	 * @return 成功返回true，失败返回false。
	 */
	template <typename ProdType>
	bool add_factory(const KeyType& key, bool override = false)
		{ return m_holder.insert_object(key, new Factory<ProdType>, override); }

	/**
	 * @brief 删除一个键为key的工厂
	 * @param key 工厂的key
	 */
	void remove_factory(const KeyType& key)
		{ m_holder.remove_object(key); }

	/**
	 * @brief 获取一个键为key的工厂
	 * @param key 工厂的key
	 * @return 如果成功获取到工厂，则返回指向该工厂的指针，如果key对应的工厂不存在，则返回0
	 */
	const AbstractFactory* get_factory(const KeyType& key) const
		{ return m_holder.get_object(key); }

private:
	/*! 保存所有工厂 */
	ObjectRegistry<KeyType, AbstractFactory> m_holder;
};

}

#endif // LIBTAOMEEPP_FACTORY_HPP_

