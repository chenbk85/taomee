#include "thread.hpp"

namespace taomee {

#ifdef NONINLINE
#include "thread.tcpp"
#endif

} // end of namespace taomee
