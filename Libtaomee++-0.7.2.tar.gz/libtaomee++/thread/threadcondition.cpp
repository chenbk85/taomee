#include "threadcondition.hpp"

namespace taomee {

#ifdef NONINLINE
#include "threadcondition.tcpp"
#endif

} // end of namespace taomee
