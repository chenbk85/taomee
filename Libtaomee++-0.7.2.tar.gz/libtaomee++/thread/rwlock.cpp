#include "rwlock.hpp"

namespace taomee {

#ifdef NONINLINE
#include "rwlock.tcpp"
#endif

} // end of namespace taomee
