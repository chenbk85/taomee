#include "mutex.hpp"

namespace taomee {

#ifdef NONINLINE
#include "mutex.tcpp"
#endif

} // end of namespace taomee
