/**
 *============================================================
 *  @file      socket.hpp
 *  @brief    TODO
 * 
 *  compiler   gcc4.1.2
 *  platform   Linux
 *
 *  copyright:  TaoMee, Inc. ShangHai CN. All rights reserved.
 *
 *============================================================
 */

#ifndef LIBTAOMEEPP_SOCKET_HPP_
#define LIBTAOMEEPP_SOCKET_HPP_

#include <cerrno>		// for errno
#include <cstring>		// for strerror

#include <stdexcept>	// For exception class

#include <libtaomee++/core/file_desc.hpp>

extern "C" {
#include <netinet/in.h>
#include <sys/socket.h>
}

namespace taomee {


/**
  * @brief Signals a problem with the execution of a socket call.
  */
class SocketError : public std::runtime_error {
public:
	/**
	  * @brief Construct a SocketError with a explanatory message.
	  * @param msg explanatory message: if 'msg' is empty (size() == 0),
	  *                   then system message (from strerror(errno)) is used.
	  * @param err   TODO
	  */
	  SocketError(const std::string& msg, int err = 0) throw()
	  	: std::runtime_error(msg + (err ? std::string(": ") + std::strerror(err) : ""))
	  {
	  }
};

/**
 * @brief Base class representing basic communication endpoint
 */
class Socket : public FileDescriptor {
protected:
	/**
	  * @brief Protocol family
	  */
	enum ProtoFamily {
		/*! ipv4 */
		pf_ipv4		= PF_INET,
		/*! ipv6 */
		pf_ipv6		= PF_INET6,
		/*! unix domain */
		pf_local	= PF_LOCAL,
		/*		
			PF_IPX				IPX - Novell protocols
			PF_NETLINK			Kernel user interface device	 netlink(7)
			PF_X25				ITU-T X.25 / ISO-8208 protocol	 x25(7)
			PF_AX25 			Amateur radio AX.25 protocol
			PF_ATMPVC			Access to raw ATM PVCs
			PF_APPLETALK		Appletalk						 ddp(7)
			PF_PACKET			Low level packet interface		 packet(7)
		*/
	};

	/**
	  * @brief Socket Type: Some socket types may not be implemented by all protocol families;
	  *                             for example, SOCK_SEQPACKET  is  not  implemented  for AF_INET.
	  */
	enum SocketType {
		/*! tcp */
		sock_tcp	= SOCK_STREAM,
		/*! udp */
		sock_udp	= SOCK_DGRAM,
		/*
		       SOCK_SEQPACKET
		              Provides  a  sequenced,  reliable,  two-way connection-based data transmission path for datagrams of fixed maximum
		              length; a consumer is required to read an entire packet with each input system call.
		       SOCK_RAW
		              Provides raw network protocol access.
		       SOCK_RDM
		              Provides a reliable datagram layer that does not guarantee ordering.
		*/
	};

	/**
	  * @brief Protocol Type
	  */
	enum ProtoType {
		/*! */
		proto_def	= 0,
		/*! tcp protocol */
		ip_tcp		= IPPROTO_TCP,
		/*! udp protocol */
		ip_udp		= IPPROTO_UDP,
		// IPPROTO_SCTP,
	};

public:
	/**
	  * @brief Close and deallocate this socket
	  
	  The default action of close with a TCP socket is to mark the socket as closed and return to the process immediately.
	  The socket descriptor is no longer usable by the process: It cannot be used as an argument to read or write.
	  But, TCP will try to send any data that is already queued to be sent to the other end, and after this occurs, the normal
	  TCP connection termination sequence takes place.
	  
	  But the SO_LINGER socket option will change this default action with a TCP socket.	    
	  */

	/**
	  *   @brief Get the local address
	  *   @return local address of socket
	  *   @throw SocketError thrown if fetch fails
	  */
	const std::string& get_local_ip() throw(SocketError);

	/**
	  *   @brief Get the local port
	  *   @return local port of socket
	  *   @throw SocketError thrown if fetch fails
	  */
	int get_local_port() throw(SocketError);

//protected:
	/**
	  *   @brief Set the local port to the specified port and the local address to any interface
	  *   @param TODO
	  *   @throw SocketError thrown if setting local port fails
	  */
	void bind_address(const std::string& addr = "", int port = 0) throw(SocketError);
#if 0
// check tcp bind, udp bind and unix domain bind
	/**
	*   Set the local port to the specified port and the local address
	*   to any interface
	*   @param localPort local port
	*   @exception SocketError thrown if setting local port fails
	*/
	void setLocalPort(unsigned short localPort) throw(SocketError);

	/**
	*   Set the local port to the specified port and the local address
	*   to the specified address.  If you omit the port, a random port 
	*   will be selected.
	*   @param localAddress local address
	*   @param localPort local port
	*   @exception SocketError thrown if setting local port or address fails
	*/
	void setLocalAddressAndPort(const string &localAddress, 
	unsigned short localPort = 0) throw(SocketError);

#endif

//protected:
public:
	/**
	  *   @brief TODO
	  *   @param pf TODO
	  *   @param type TODO
	  *   @param proto Should be set to the specific protocol type found in ProtoType. 'proto_def' is set by default
	  *                       to select the system's default for the given combination of family and type.
	  *   @throw SocketError
	  */
	Socket(ProtoFamily pf, SocketType type, ProtoType proto) throw(SocketError)
	{
		m_pf = pf;
		m_local_port = -1;
		m_fd = socket(pf, type, proto);
		if (m_fd == -1) {
			throw SocketError("Socket creation failed (socket())", errno);
		}
	}

private:
	/**
	  * @brief fill in address structure given an address and port
	  */
	sockaddr_storage fill_address(const std::string& addr, int port, socklen_t& len);

private:
	/*! Socket File Descriptor */
	int m_sockfd;
	/*! Protocol Family */
	ProtoFamily m_pf;
	/*! hold local ip address */
	std::string m_local_ipaddr;
	/*! hold local port */
	int m_local_port;
};

} // namespace taomee

#endif // LIBTAOMEEPP_SOCKET_HPP_

