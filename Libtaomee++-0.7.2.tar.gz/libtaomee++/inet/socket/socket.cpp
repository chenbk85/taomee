#include <sstream>

extern "C" {
#include <arpa/inet.h>
#include <sys/un.h>
}

#include <libtaomee++/inet/byteswap.hpp>

#include "socket.hpp"

using namespace std;


namespace taomee {

// in_port_t uint16, port 0 invalid
const string& Socket::get_local_ip() throw(SocketError)
{
	if (m_local_ipaddr.size()) {
		return m_local_ipaddr;
	}

	// get socket address
	sockaddr_storage addr;
	socklen_t len = sizeof(addr);
	if (getsockname(m_sockfd, reinterpret_cast<sockaddr*>(&addr), &len) == -1) {
		throw SocketError("Fetch of local address failed (getsockname())", errno);
	}

	// set src to point to the beginning of the numeric address
	const void* src;
	int port;
	switch (addr.ss_family) {
	case pf_local:
		m_local_ipaddr = reinterpret_cast<sockaddr_un*>(&addr)->sun_path;
		return m_local_ipaddr;
	case pf_ipv4:
		src  = &reinterpret_cast<sockaddr_in*>(&addr)->sin_addr;
		port = reinterpret_cast<sockaddr_in*>(&addr)->sin_port;
		break;
	case pf_ipv6:
		src  = &reinterpret_cast<sockaddr_in6*>(&addr)->sin6_addr;
		port = reinterpret_cast<sockaddr_in6*>(&addr)->sin6_port;
		break;
	default:
		src = 0;
		break;
	}

	// convert numeric socket address to string
	char buf[sizeof(sockaddr_storage)];
	if (inet_ntop(addr.ss_family, src, buf, sizeof(buf)) == 0) {
		ostringstream oss;
		oss << addr.ss_family;
		throw SocketError(string("Family: ") + oss.str() + ". Fetch of local address failed (inet_ntop())", errno);
	}

	m_local_port   = ntohs(port);
	m_local_ipaddr = buf;
	return m_local_ipaddr;
}

int Socket::get_local_port() throw(SocketError)
{
	if (m_local_port != -1) {
		return m_local_port;
	}

	// get socket address
	sockaddr_storage addr;
	socklen_t len = sizeof(addr);
	if (getsockname(m_sockfd, reinterpret_cast<sockaddr*>(&addr), &len) == -1) {
		throw SocketError("Fetch of local port failed (getsockname())", errno);
	}

	// get port
	switch (addr.ss_family) {
	case pf_ipv4:
		m_local_port = bswap(reinterpret_cast<sockaddr_in*>(&addr)->sin_port);
		break;
	case pf_ipv6:
		m_local_port = bswap(reinterpret_cast<sockaddr_in6*>(&addr)->sin6_port);
		break;
	default:
		{
			ostringstream oss;
			oss << addr.ss_family;
			throw SocketError(string("Family: ") + oss.str() + ". Fetch of local port failed");
		}
	}

	return m_local_port;
}

sockaddr_storage Socket::fill_address(const string& addr, int port, socklen_t& len)
{
	sockaddr_storage ss;
	memset(&ss, 0, sizeof(ss));
	ss.ss_family = m_pf;

	// set address
	void* dst;
	switch (m_pf) {
	case pf_local:
		{
			sockaddr_un* un = reinterpret_cast<sockaddr_un*>(&ss);
			strncpy(un->sun_path, addr.c_str(), sizeof(un->sun_path) - 1);
			len = SUN_LEN(un);
			return ss;
		}
	case pf_ipv4:
		reinterpret_cast<sockaddr_in*>(&ss)->sin_port = htons(port);
		dst  = &reinterpret_cast<sockaddr_in*>(&ss)->sin_addr;
		len  = sizeof(sockaddr_in);
		break;
	case pf_ipv6:
		reinterpret_cast<sockaddr_in6*>(&ss)->sin6_port = htons(port);
		dst  = &reinterpret_cast<sockaddr_in6*>(&ss)->sin6_addr;
		len  = sizeof(sockaddr_in6);
		break;
	default:
		dst  = 0;
		break;
	}
	//-----------------------------

	if (inet_pton(m_pf, addr.c_str(), dst) != 1) {
		throw SocketError(string("Failed to convert address (inet_pton): ") + addr);
	}

	return ss;


//	addr.sin_addr.s_addr = *((unsigned long *) host->h_addr_list[0]);
	
	
//	13	   servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	
//	15	   Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));
	
}

void Socket::bind_address(const std::string& addr, int port) throw(SocketError)
{
// Get the address of the requested host
socklen_t len;
sockaddr_storage ss = fill_address(addr, port, len);

if (bind(m_sockfd, reinterpret_cast<sockaddr*>(&ss), sizeof(ss)) < 0) {
  throw SocketError("Set of local address and port failed (bind())", errno);
}
}


#if 0
void Socket::bind_address(const std::string& addr, int port) throw(SocketError)
{
// Get the address of the requested host
sockaddr_in localAddr;
fillAddr(localAddress, localPort, localAddr);

if (bind(sockDesc, (sockaddr *) &localAddr, sizeof(sockaddr_in)) < 0) {
  throw SocketException("Set of local address and port failed (bind())", true);
}



// Bind the socket to its port
sockaddr_in localAddr;
memset(&localAddr, 0, sizeof(localAddr));
localAddr.sin_family = AF_INET;
localAddr.sin_addr.s_addr = htonl(INADDR_ANY);
localAddr.sin_port = htons(localPort);

if (bind(sockDesc, (sockaddr *) &localAddr, sizeof(sockaddr_in)) < 0) {
  throw SocketException("Set of local port failed (bind())", true);
}


}
#endif

}

