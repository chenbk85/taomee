#!/bin/bash

sudo make all 2>/dev/null
