#!/usr/bin/python
# -*- coding: utf-8 -*-
#import pexpect
#import sys  
import pexpect, struct, fcntl, termios, signal, sys
import termpub
import os 

ter=None
ssh_outfile=""
ssh_outfile_fd=False
ssh_null_fd=file("/dev/null","w+");

def run_scp (cmd,password):
	t_ter= pexpect.spawn(cmd)
	while True:
		try:
			index=t_ter.expect (['yes',"assword"],0.3 )
			if index==0:
				t_ter.sendline ("yes" )
				t_ter.sendline ( password )
				break;
			elif index==1:	
				t_ter.sendline ( password )
				break;
		except Exception:	
			pass
	#进入用户交互
	try:
		t_ter.interact()
	except Exception:	
		pass
#


#自动telnet 函数
def auto_ssh (ip,username,password):
	global ter

	ip_addr=ip.split(":")[0];
	#如果带端口,将":" 转化为空格,以便于telnet使用.
	ip=ip.replace(":"," -p")
	ssh_cmd="./ssh."+ termpub.g_cur_sys_word_bit+" " +username+"@" + ip
	print "\033[35m+<<=====================================\033[33m|\033[32m SSH \033[33m|\033[35m=======================================>>+\033[0m"
	print "\033[34m ssh_cmd\t:\033[0m "+ssh_cmd

	print "\033[36m+=======================================================================================+\033[0m"
	ssh_outfile_fd.write("\n\n\n====================================================================\n" );
	ssh_outfile_fd.write("=======================["+ssh_cmd+"]===================\n" );

	ssh_outfile_fd.write("====================================================================\n\n\n\n" );

	ter= pexpect.spawn(ssh_cmd)
	ter.logfile=ssh_null_fd

	while True:
		try:
			index=ter.expect (['yes',"assword","[#$]","REMOTE HOST IDENTIFICATION HAS CHANGED"],0.1 )
			if index==0:
				print "print yes"
				ter.sendline ("yes" )
			elif index==1:	
				print "print passwd"
				ter.sendline ( password )
			elif index==2:	
				print "login ...."
				break;
			elif index==3:#地址出问题了	
				rm_item_str="sed -i '/%s/d' %s/.ssh/known_hosts"% (ip_addr ,os.getenv("HOME"));
				os.system(rm_item_str );
				#print rm_item_str 
				print "请重新登入 "
				break;
				pass
		except Exception:	
			pass

########################################################
#设置终端
def sigwinch_passthrough (sig, data):
	s = struct.pack("HHHH", 0, 0, 0, 0)
	a = struct.unpack('hhhh', fcntl.ioctl(sys.stdout.fileno(), termios.TIOCGWINSZ , s))
	global ter 
	ter.setwinsize(a[0],a[1])
	
#---------------------------

#---------------------------
def run_ssh(ip,username,passwd ):
	global ter
	auto_ssh(ip,username,passwd)
	#设置当前winsize
	sigwinch_passthrough(0,0)
	signal.signal(signal.SIGWINCH, sigwinch_passthrough)	
	ter.logfile=ssh_outfile_fd
	#进入用户交互
	try:
		ter.interact()
	except Exception:	
		pass
#######################################################
