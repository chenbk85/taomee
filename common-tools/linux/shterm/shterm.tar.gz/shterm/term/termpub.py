#!/usr/bin/python
# -*- coding: utf-8 -*-
g_login_session_id="";
g_username="";
#scp :保存文件的位置
g_scp_data_dir="";
#当前ssh 的连接参数
g_cur_ssh_cmd=""

#当前系统是多少位的:32/64,不写的话，自动检测
g_cur_sys_word_bit=""


#以下参数需要手工设置

#DB的配置
db_host="localhost"
db_user="term"
db_passwd="termpwd"

#SSH 中DB账户:用户保存用户的输入 ,只需要insert t_user_opt_info 表的权限 
ssh_input_db_host="localhost"
ssh_input_db_user="term"
ssh_input_db_passwd="termpwd"

