#!/usr/bin/env python
# -*- coding: utf-8 -*-
import threading
import time
import db 
import termpub

class sync_power(threading.Thread):
	def __init__(self, threadName):
		threading.Thread.__init__(self, name = threadName)
		self.runflag=True;
	def set_stop(self):
		self.runflag=False;

	def run(self):
		i=0
		while self.runflag   :
			if i % 300 ==0 :
				db.get_user_cmd_list(termpub.g_username);
			time.sleep(1)
			i=i+1
