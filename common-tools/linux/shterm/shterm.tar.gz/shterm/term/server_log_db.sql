-- MySQL dump 10.11
--
-- Host: localhost    Database: SERVER_LOG_DB
-- ------------------------------------------------------
-- Server version	5.0.32-Debian_7etch8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_group`
--
create database SERVER_LOG_DB;
use SERVER_LOG_DB;

DROP TABLE IF EXISTS `t_group`;
CREATE TABLE `t_group` (
  `groupid` int(10) unsigned NOT NULL auto_increment,
  `groupname` varchar(64) NOT NULL,
  PRIMARY KEY  (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `t_group_server_login`
--

DROP TABLE IF EXISTS `t_group_server_login`;
CREATE TABLE `t_group_server_login` (
  `groupid` int(10) unsigned NOT NULL,
  `loginid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`groupid`,`loginid`),
  KEY `fk_name_1` (`loginid`),
  CONSTRAINT `fk_name` FOREIGN KEY (`groupid`) REFERENCES `t_group` (`groupid`) ON UPDATE CASCADE,
  CONSTRAINT `fk_name_1` FOREIGN KEY (`loginid`) REFERENCES `t_server_login` (`loginid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `t_group_user`
--

DROP TABLE IF EXISTS `t_group_user`;
CREATE TABLE `t_group_user` (
  `groupid` int(10) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  PRIMARY KEY  (`groupid`,`username`),
  KEY `g_fk_name` (`username`),
  CONSTRAINT `g_fk_name` FOREIGN KEY (`username`) REFERENCES `t_user` (`username`) ON UPDATE CASCADE,
  CONSTRAINT `g_fk_name_1` FOREIGN KEY (`groupid`) REFERENCES `t_group` (`groupid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `t_server_login`
--

DROP TABLE IF EXISTS `t_server_login`;
CREATE TABLE `t_server_login` (
  `loginid` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(16) NOT NULL,
  `port` int(10) unsigned NOT NULL,
  `loginname` varchar(32) NOT NULL,
  `loginpasswd` blob NOT NULL,
  `descstr` varchar(128) NOT NULL,
  PRIMARY KEY  (`loginid`),
  UNIQUE KEY `ip` (`ip`,`loginname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `username` varchar(32) NOT NULL,
  `createtime` int(10) unsigned NOT NULL default '0',
  `useflag` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `t_user_login_log`
--

DROP TABLE IF EXISTS `t_user_login_log`;
CREATE TABLE `t_user_login_log` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(32) NOT NULL,
  `starttime` datetime default NULL,
  `endtime` datetime default NULL,
  `loginip` varchar(16) NOT NULL,
  `logflie` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`,`starttime`),
  KEY `starttime` (`starttime`,`endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `t_user_opt_info`
--

DROP TABLE IF EXISTS `t_user_opt_info`;
CREATE TABLE `t_user_opt_info` (
  `opttype` int(10) unsigned NOT NULL,
  `login_session_id` int(10) unsigned NOT NULL,
  `logtime` datetime default NULL,
  `username` varchar(32) NOT NULL,
  `cmdstr` varchar(512) NOT NULL,
  KEY `username` (`username`),
  KEY `opttype` (`opttype`,`username`),
  KEY `logtime` (`logtime`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-11-19  5:28:46
