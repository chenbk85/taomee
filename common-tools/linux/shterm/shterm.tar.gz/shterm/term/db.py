#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
import re
import termpub 
try:
	import MySQLdb
except Exception:	
	pass
g_ip_flag_conf={
	"10.1.1":"t",
	"192.168.0":"m",
	"192.168.1":"b",
	"192.168.2":"p",
	"192.168.3":"c",
	"192.168.4":"d",
	"192.168.5":"e",
	"192.168.6":"f",
	"192.168.7":"g",
	"192.168.61":"d",
}
g_server_login_list={ }

def get_db():
	conn=MySQLdb.connect(host=termpub.db_host ,user=termpub.db_user ,passwd=termpub.db_passwd,db="SERVER_LOG_DB")
	conn.autocommit(True)
	return conn 


def get_db_curor():
	conn=MySQLdb.connect(host=termpub.db_host ,user=termpub.db_user ,passwd=termpub.db_passwd,db="SERVER_LOG_DB")
	conn.autocommit(True)
	return conn.cursor()

def insert_login_record(username,starttime,loginip,logfile ):
	db=get_db();
	cursor=db.cursor()
	sql="insert into t_user_login_log values (0,'%s','%s',0,'%s','%s' )"%(username,starttime,loginip,logfile);
	cursor.execute(sql)
	return db.insert_id();
	pass

def insert_user_opt(login_session_id,username,opttype ,cmdstr  ):
	cursor=get_db_curor( )
	sql="insert into t_user_opt_info values(%u,%u,now(),'%s','%s' ) "%(
			opttype,login_session_id,username,cmdstr );
	cursor.execute(sql)
	pass



def set_login_end(username,starttime,endtime):
	cursor=get_db_curor()
	sql="update t_user_login_log set endtime='%s' where username='%s' and starttime='%s'"%(
			endtime, username,starttime);
	cursor.execute(sql)
	pass

def get_user_cmd_list(username):
	cursor=get_db_curor()
	sql="""select t4.ip,t4.port, t4.loginname ,DECODE(t4.loginpasswd , 'getipforhello'), t4.descstr  from t_user t1,t_group_user t2, t_group_server_login t3, t_server_login t4 where t1.username=t2.username and t2.groupid=t3.groupid and t3.loginid=t4.loginid and t1.username='%s' and  t1.useflag=1 ;""" %username;
	cursor.execute(sql)
	cds=cursor.fetchall()
  	global g_server_login_list
	g_server_login_list={ }
	for i in range (0,len(cds)):	
		ip=cds[i][0];
		port=cds[i][1];
		loginname=cds[i][2];
		loginpasswd=cds[i][3];
		descstr=cds[i][4];
		if (not g_server_login_list.has_key(ip)): g_server_login_list[ip]={}
		ip_list=g_server_login_list[ip];
		ip_list[loginname]={}
		ip_list[loginname]["port"]=port;
		ip_list[loginname]["passwd"]=loginpasswd;
		ip_list[loginname]["descstr"]=descstr;
		ip_list[loginname]["full_cmd"]="l "+loginname+"@"+ip

	g_ip_flag_info={}
	#得到ip段 的分布
	for  ip in g_server_login_list :
		ip_list=g_server_login_list[ip];
		m=re.match(r"(.*)\.(\d+)",ip)
		ip_flag=m.group(1)
		if (not g_ip_flag_info.has_key(ip_flag)): g_ip_flag_info[ip_flag]=1
		else:g_ip_flag_info[ip_flag]= g_ip_flag_info[ip_flag]+1
		 
	max_ip_flag=""															 
	max_ip_flag_count=0															 
	for ip_flag  in g_ip_flag_info:		
		if g_ip_flag_info[ip_flag]>max_ip_flag_count :
			max_ip_flag=ip_flag;
			max_ip_flag_count=g_ip_flag_info[ip_flag] ;

	#最经常用的段设置为空
	g_ip_flag_conf[max_ip_flag]=""
	

	#创建快捷方式
	for  ip in g_server_login_list :
		ip_list=g_server_login_list[ip];
		m=re.match(r"(.*)\.(\d+)",ip)
		ip_flag=m.group(1)
		ip_end=m.group(2)
		for username in ip_list: 
			if (len(ip_list)==1):#只一个账户
				ip_list[username]["cut_cmd"]="c"+g_ip_flag_conf[ip_flag]+ip_end
			else:
				ip_list[username]["cut_cmd"]="c"+g_ip_flag_conf[ip_flag]+ip_end+username

#--------------------------------------------------------
def get_login_info(cmd):
  	global g_server_login_list
	cmd=re.sub("\s+"," ",cmd)
	#check
	for  ip in g_server_login_list :
		ip_list=g_server_login_list[ip];
		for username in ip_list: 
			if ip_list[username]["cut_cmd"]==cmd or ip_list[username]["full_cmd"]==cmd:
				return (ip,ip_list[username]["port"] ,username,ip_list[username]["passwd"],ip_list[username]["full_cmd"] )
	return False;

def get_login_info_by_ip_username(ip,username ):
  	global g_server_login_list
	if g_server_login_list.has_key(ip):
		return g_server_login_list[ip][username];
	else:
		return False;
