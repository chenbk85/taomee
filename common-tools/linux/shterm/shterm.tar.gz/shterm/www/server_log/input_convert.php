<?php
  /*
  key code:
  ESC:[1B ]
  F1: [1B 5B 5B 41 ]
  F2: [1B 5B 5B 42 ]
  F3: [1B 5B 5B 43 ]
  F4: [1B 5B 5B 44 ]
  F5: [1B 5B 5B 45 ]
  F6: [1B 5B 31 37 7E ]
  F7: [1B 5B 31 38 7E ]
  F8: [1B 5B 31 39 7E ]
  F9: [1B 5B 32 30 7E ]
  F10:[1B 5B 32 31 7E ]
  F11:[1B 5B 32 33 7E ]
  F12:[1B 5B 32 34 7E ]    

  Insert:   [1B 5B 32 7E ]
  Home:     [1B 5B 31 7E ]
  page up:  [1B 5B 35 7E ]
  page Down:[1B 5B 36 7E ]
  End:      [1B 5B 34 7E ]
  Delete:   [1B 5B 33 7E ]

  up:   [1B 5B 41 ]
  down: [1B 5B 42 ]
  left: [1B 5B 44 ]
  right:[1B 5B 43 ]

  Ctrl+2:[00 ]
  Ctrl+6:[1E ]
  Ctrl+q:[11 ]
  Ctrl+w:[17 ]
  Ctrl+e:[05 ]
  Ctrl+r:[12 ]
  Ctrl+t:[14 ]
  Ctrl+y:[19 ]
  Ctrl+u:[15 ]
  Ctrl+i:[09 ]
  Ctrl+o:[0F ]
  Ctrl+p:[10 ]
  Ctrl+a:[01 ]
  Ctrl+s:[13 ]
  Ctrl+d:[04 ]
  Ctrl+f:[06 ]
  Ctrl+g:[07 ]
  Ctrl+h:[08 ]
  Ctrl+j:[0A ]
  Ctrl+k:[0B ]
  Ctrl+l:[0C ]
  Ctrl+z:[1A ]
  Ctrl+x:[18 ]
  Ctrl+c:[03 ]
  Ctrl+v:[16 ]
  Ctrl+b:[02 ]
  Ctrl+n:[0E ]
  Enter :[0D ]
  */
  function input_convert($cmd_str){
	define ("ESC","[ESC]");
	define ("F1","[F1]");
	define ("F2","[F2]");
	define ("F3","[F3]");
	define ("F4","[F4]");
	define ("F5","[F5]");
	define ("F6","[F6]");
	define ("F7","[F7]");
	define ("F8","[F8]");
	define ("F9","[F9]");
	define ("F10","[F10]");
	define ("F11","[F11]");
	define ("F12","[F12]");
	define ("INSERT","[Insert]");
	define ("HOME","[Home]");
	define ("PAGEUP","[PageUp]");
	define ("PAGEDOWN","[pageDown]");
	define ("END1","[End]");
	define ("DELETE","[Delete]");
	define ("UP","[up]");
	define ("DOWN","[down]");
	define ("LEFT","[left]");
	define ("RIGHT","[right]");
	define ("CTRL_2","[Ctrl+2]");
	define ("CTRL_6","[Ctrl+6]");
	define ("CTRL_Q","[Ctrl+q]");
	define ("CTRL_W","[Ctrl+w]");
	define ("CTRL_E","[Ctrl+e]");
	define ("CTRL_R","[Ctrl+r]");
	define ("CTRL_T","[Ctrl+t]");
	define ("CTRL_Y","[Ctrl+y]");
	define ("CTRL_U","[Ctrl+u]");
	define ("CTRL_I","[TAB]"); //TAB ->Ctrl+i
	define ("CTRL_O","[Ctrl+o]");
	define ("CTRL_P","[Ctrl+p]");
	define ("CTRL_A","[Ctrl+a]");
	define ("CTRL_S","[Ctrl+s]");
	define ("CTRL_D","[Ctrl+d]");
	define ("CTRL_F","[Ctrl+f]");
	define ("CTRL_G","[Ctrl+g]");
	define ("CTRL_H","[Ctrl+h]");
	define ("CTRL_J","[Ctrl+j]");
	define ("CTRL_K","[Ctrl+k]");
	define ("CTRL_L","[Ctrl+l]");
	define ("CTRL_Z","[Ctrl+z]");
	define ("CTRL_X","[Ctrl+x]");
	define ("CTRL_C","[Ctrl+c]");
	define ("CTRL_V","[Ctrl+v]");
	define ("CTRL_B","[Ctrl+b]");
	define ("CTRL_N","[Ctrl+n]");
	define ("ENTER","[Enter]");
	define ("BACKSPACE","[<--]");

    //$cmd_str = "1B 5B 5B 41 00 05 1B 5B 41 1B 5B 31 7E 1B 5B 34 7E 1B 0A 0D 76 78 2E 1B 5B 31 37 7E 11 11 67 68 0C 1B 5B 5B 44  ";
	$bindata = "";
	$cmd_str_shuzu = explode(" ",$cmd_str);
	$str_count = count($cmd_str_shuzu);
	for($i=0;$i<$str_count-1;$i++){
		$tmp_str = "";
		if($cmd_str_shuzu[$i]=="1B"){
			if($i+1<$str_count && $cmd_str_shuzu[$i+1]=="5B"){
				if($i+2<$str_count){
					if($cmd_str_shuzu[$i+2]=="41"){
						$tmp_str = UP;
						$i+=2;
					}else if($cmd_str_shuzu[$i+2]=="42"){
						$tmp_str = DOWN;
						$i+=2;
					}else if($cmd_str_shuzu[$i+2]=="43"){
						$tmp_str = RIGHT;
						$i+=2;
					}else if($cmd_str_shuzu[$i+2]=="44"){
						$tmp_str = LEFT;
						$i+=2;
					}else if($cmd_str_shuzu[$i+2]=="31"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="7E"){
								$tmp_str = HOME;
								$i+=3;
							}else if($cmd_str_shuzu[$i+3]=="37"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F6;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else if($cmd_str_shuzu[$i+3]=="38"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F7;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else if($cmd_str_shuzu[$i+3]=="39"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F8;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}else if($cmd_str_shuzu[$i+2]=="32"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="7E"){
								$tmp_str = INSERT;
								$i+=3;
							}else if($cmd_str_shuzu[$i+3]=="30"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F9;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else if($cmd_str_shuzu[$i+3]=="31"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F10;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else if($cmd_str_shuzu[$i+3]=="33"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F11;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else if($cmd_str_shuzu[$i+3]=="34"){
								if($i+4<$str_count){
									if($cmd_str_shuzu[$i+4]=="7E"){
										$tmp_str = F12;
										$i+=4;
									}else{
										$tmp_str = ESC;
									}
								}else{
									$tmp_str = ESC;
								}
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}else if($cmd_str_shuzu[$i+2]=="33"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="7E"){
								$tmp_str = DELETE;
								$i+=3;
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}else if($cmd_str_shuzu[$i+2]=="34"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="7E"){
								$tmp_str = END1;
								$i+=3;
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}else if($cmd_str_shuzu[$i+2]=="35"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="7E"){
								$tmp_str = PAGEUP;
								$i+=3;
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}else if($cmd_str_shuzu[$i+2]=="36"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="7E"){
								$tmp_str = PAGEDOWN;
								$i+=3;
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}else if($cmd_str_shuzu[$i+2]=="5B"){
						if($i+3<$str_count){
							if($cmd_str_shuzu[$i+3]=="41"){
								$tmp_str = F1;
								$i+=3;
							}else if($cmd_str_shuzu[$i+3]=="42"){
								$tmp_str = F2;
								$i+=3;
							}else if($cmd_str_shuzu[$i+3]=="43"){
								$tmp_str = F3;
								$i+=3;
							}else if($cmd_str_shuzu[$i+3]=="44"){
								$tmp_str = F4;
								$i+=3;
							}else{
								$tmp_str = ESC;
							}
						}else{
							$tmp_str = ESC;
						}
					}
				}else{
					$tmp_str = ESC;
				}
			}else{
				$tmp_str = ESC;
			}
			//$bindata .= $tmp_str;
		}else if($cmd_str_shuzu[$i]=="00"){
			$tmp_str = CTRL_2;
		}else if($cmd_str_shuzu[$i]=="1E"){
			$tmp_str = CTRL_6;
		}else if($cmd_str_shuzu[$i]=="11"){
			$tmp_str = CTRL_Q;
		}else if($cmd_str_shuzu[$i]=="17"){
			$tmp_str = CTRL_W;
		}else if($cmd_str_shuzu[$i]=="05"){
			$tmp_str = CTRL_E;
		}else if($cmd_str_shuzu[$i]=="12"){
			$tmp_str = CTRL_R;
		}else if($cmd_str_shuzu[$i]=="14"){
			$tmp_str = CTRL_T;
		}else if($cmd_str_shuzu[$i]=="19"){
			$tmp_str = CTRL_Y;
		}else if($cmd_str_shuzu[$i]=="15"){
			$tmp_str = CTRL_U;
		}else if($cmd_str_shuzu[$i]=="09"){
			$tmp_str = CTRL_I;
		}else if($cmd_str_shuzu[$i]=="0F"){
			$tmp_str = CTRL_O;
		}else if($cmd_str_shuzu[$i]=="10"){
			$tmp_str = CTRL_P;
		}else if($cmd_str_shuzu[$i]=="01"){
			$tmp_str = CTRL_A;
		}else if($cmd_str_shuzu[$i]=="13"){
			$tmp_str = CTRL_S;
		}else if($cmd_str_shuzu[$i]=="04"){
			$tmp_str = CTRL_D;
		}else if($cmd_str_shuzu[$i]=="06"){
			$tmp_str = CTRL_F;
		}else if($cmd_str_shuzu[$i]=="07"){
			$tmp_str = CTRL_G;
		}else if($cmd_str_shuzu[$i]=="08"){
			$tmp_str = CTRL_H;
		}else if($cmd_str_shuzu[$i]=="0A"){
			$tmp_str = CTRL_J;
		}else if($cmd_str_shuzu[$i]=="0B"){
			$tmp_str = CTRL_K;
		}else if($cmd_str_shuzu[$i]=="0C"){
			$tmp_str = CTRL_L;
		}else if($cmd_str_shuzu[$i]=="1A"){
			$tmp_str = CTRL_Z;
		}else if($cmd_str_shuzu[$i]=="18"){
			$tmp_str = CTRL_X;
		}else if($cmd_str_shuzu[$i]=="03"){
			$tmp_str = CTRL_C;
		}else if($cmd_str_shuzu[$i]=="16"){
			$tmp_str = CTRL_V;
		}else if($cmd_str_shuzu[$i]=="02"){
			$tmp_str = CTRL_B;
		}else if($cmd_str_shuzu[$i]=="0E"){
			$tmp_str = CTRL_N;
		}else if($cmd_str_shuzu[$i]=="0D"){
			$tmp_str = ENTER;
		}else if($cmd_str_shuzu[$i]=="7F"){
			$tmp_str = BACKSPACE;
		}else{
			$tmp_str = chr(hexdec($cmd_str_shuzu[$i]));
		}
		$bindata .= $tmp_str;
	}
	//print_r($cmd_str_shuzu);
	//print_r($bindata);
	return $bindata;
  }
?>
