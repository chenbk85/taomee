<?php
	require_once("../pub/comm.php");
	require_once("server_log.php");
	require_once("input_convert.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
</head>
<SCRIPT LANGUAGE="JavaScript" src="../pub/pub.js"></SCRIPT>
<script src="../pub/jquery-1.3.2.js" type="text/javascript"></script>
<script type="text/javascript">
function div_swap_show(divname ){
	p_item=$('#'+divname);  
	if (p_item.css('display')=='none'){
		p_item.show();
	}else{
		p_item.hide();
	}

}

</script>
<body >
<div align=center>
<?php
    $opt_time=$_GET["id_login_time"];
    $username=$_GET["username"];
	$db=Cserver_log::getMyiface();
	$user_list=$db->user_login_get_list($opt_time,$username);
	
	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >登入记录
		<tr ><th>会话Id<th>用户名 <th>开始时间<th>结束时间<th>ip<th>日志文件</tr>
		";
	for ($i=0;$i<count($user_list);$i++){
		printf( "<tr > 
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s <a href='./show_login_outlog.php?login_session_id=%u&filename=%s' target=_blank > 查看 </a>
			</tr>",
			$user_list[$i][0],
			$user_list[$i][1],
			$user_list[$i][2],
			$user_list[$i][3],
			$user_list[$i][4],
			$user_list[$i][5],
			$user_list[$i][0],
			$user_list[$i][5]
	   	);
	}
	echo "</table>";

$user_list=$db->get_user_input($opt_time,$username);

	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >用户操作
		<tr ><th>会话id<th>用户<th>类型<th>操作时间<th>命令输入 </tr>
		";

	for ($i=0;$i<count($user_list);$i++){
		$opttype=$user_list[$i][2];
		switch ($opttype ){
			case 1:
				 $user_list[$i][4]=input_convert($user_list[$i][4]);//hex->input
		};
		
		printf( "<tr > 
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			</tr>",
			$user_list[$i][0],
			$user_list[$i][1],
			$opttype_conf[$opttype],
			$user_list[$i][3],
			$user_list[$i][4]
	   	);
	}
	echo "</table>";


	



?>

</div>
</body>
</html>
