<?php
require_once("../pub/comm.php");
require_once("server_log.php");

$R=$_REQUEST;
$db=Cserver_log::getMyiface();
$ret_arr=$db->select_group_server_login_list($R["groupid"],$R["in_flag"]);
echo $R["index"]; 
foreach ($ret_arr  as $item ){
	echo  ":".$item[0]."|".$item[1]."@".$item[2];
}
?>
