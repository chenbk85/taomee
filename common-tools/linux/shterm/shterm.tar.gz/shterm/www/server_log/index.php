<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>用户资料</title>
</head>
<frameset rows ="70,* "   frameborder=0 >
<frame name="head_frm"  scrolling="no" src="./input_frm.php" >
<frame id="show_frm" name="show_frm"  scrolling="yes" src="./base_info.php">
</frameset>
</html>
