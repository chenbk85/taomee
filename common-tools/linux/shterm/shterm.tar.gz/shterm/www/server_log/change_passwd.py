#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pexpect
import sys 
import  time 
username= sys.argv[1]
print "user:", username
ter= pexpect.spawn("sudo passwd  "+username )
ter.expect ('assword:')
ter.sendline(username);
ter.expect ('assword:')
ter.sendline(username);
time.sleep(1);
ter.interact()
