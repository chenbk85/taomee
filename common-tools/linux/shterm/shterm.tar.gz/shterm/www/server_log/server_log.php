<?php
require_once("../pub/mysqlinterface.php");
require_once("../pub/comm.php");
$g_passwd_key="getipforhello";
$opttype_conf[1]="输入";
$opttype_conf[2]="ssh 连接";
$opttype_conf[3]="scp";

$ssh_db_host="localhost";
$ssh_db_user="term";
$ssh_db_passwd="termpwd";
$shterm_shell="/opt/term/shell";

	
class Cserver_log{
	var $db; //socket 句柄
	//var $debug = 1;
	function __construct( $ip,$u,$p){
		$this->db=new MysqlInterface($ip,$u,$p,"SERVER_LOG_DB");
	}
	function __destruct(){
	}
	public static function getMyiface(){ 
		global $ssh_db_host, $ssh_db_user, $ssh_db_passwd ;

		return new Cserver_log($ssh_db_host, $ssh_db_user, $ssh_db_passwd) ;

  	}

		
	function get_user_list(){
		$sqlstr="select username,createtime,useflag  from t_user ";
		#echo $sqlstr;
		$user_list=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$user_list[]=$row;	
		}
		return $user_list;
	}

	function get_group_list(){
		$sqlstr="select groupid,groupname from t_group ";
		#echo $sqlstr;
		$group_list=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$group_list[$row[0]]=$row;	
		}
		return $group_list;
	}

	function get_server_login_list(){
		$sqlstr="select loginid ,ip,port, loginname, hex(loginpasswd), descstr from t_server_login order by ip";
		#echo $sqlstr;
		$server_login_list=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$server_login_list[$row[0]]=$row;	
		}
		return $server_login_list;
	}

	function select_group_server_login_list( $groupid,$in_flag  ){
		if ($in_flag==0){
			$in_str="in";
		}else{
			$in_str="not in";
		}
		$sqlstr=sprintf ("select loginid,loginname,ip from t_server_login where loginid  %s (select loginid from t_group_server_login where groupid=%u);",$in_str,$groupid );
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$ls[]=$row;	
		}
		return $ls;
	}

	function get_group_server_login_list(){
		$sqlstr="select groupid ,loginid from t_group_server_login order by groupid ";
		#echo $sqlstr;
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$ls[]=$row;	
		}
		return $ls;
	}

	function get_group_user_list(){
		$sqlstr="select groupid , username from t_group_user order by groupid";
		#echo $sqlstr;
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$ls[]=$row;	
		}
		return $ls;
	}

	function server_login_change_passwd($loginid,$passwd  ){
		$passwd= $this->db->conn->real_escape_string($passwd);
		global $g_passwd_key;
		$sqlstr=sprintf ("update t_server_login set loginpasswd= encode('%s','%s') ".
					" where loginid=%u ",
				 $passwd, $g_passwd_key, $loginid);
		$this->db->update($sqlstr);
	}


	function server_login_change_descstr($loginid, $descstr ){
		$descstr= $this->db->conn->real_escape_string($descstr);
		$sqlstr=sprintf ("update t_server_login set descstr= '%s' ".
					" where loginid=%u ",
				 $descstr , $loginid);
		$this->db->update($sqlstr);
	}



	function server_login_add($ip,$port,$loginname, $passwd ,$descstr ){
		$ip= $this->db->conn->real_escape_string($ip);
		$loginname= $this->db->conn->real_escape_string($loginname);
		$passwd= $this->db->conn->real_escape_string($passwd);
		$descstr= $this->db->conn->real_escape_string($descstr);
		global $g_passwd_key;

		$sqlstr=sprintf ("insert into t_server_login values(0,'%s',%u,'%s',encode('%s','%s'), '%s') ",
				 $ip,$port,$loginname,$passwd, $g_passwd_key, $descstr );
		$this->db->update($sqlstr);
		return $this->db->get_insert_id(); 
		
	}

	function group_user_add($groupid,$username){
		$sqlstr=sprintf ("insert into t_group_user values(%d,'%s') ",
				$groupid,$username );
		$this->db->update($sqlstr);
	}

	function group_user_del($groupid,$username){
		$sqlstr=sprintf ("delete from t_group_user where groupid=%u and username='%s'",
				$groupid,$username );
		$this->db->update($sqlstr);
	}
	function group_server_login_del($groupid,$loginid){
		$sqlstr=sprintf ("delete from t_group_server_login where groupid=%u and loginid=%u",
				$groupid,$loginid);
		$this->db->update($sqlstr);
	}

	function group_server_login_add($groupid,$loginid){
		$sqlstr=sprintf ("insert into t_group_server_login values(%d,%d ) ",
				$groupid,$loginid);
		echo $sqlstr;
		$this->db->update($sqlstr);
	}





	function group_add($groupname){
		$sqlstr=sprintf ("insert into t_group values(0,'%s') ",
				$groupname );
		$this->db->update($sqlstr);
	}

	function group_del($groupid){
		$sqlstr=sprintf ("delete from t_group_user where groupid=%u",
				$groupid);
		$this->db->update($sqlstr);

		$sqlstr=sprintf ("delete from t_group_server_login where groupid=%u",
				$groupid);
		$this->db->update($sqlstr);

		$sqlstr=sprintf ("delete from t_group where groupid=%u ",
				$groupid);
		$this->db->update($sqlstr);
	}

	function server_login_del($loginid){
		$sqlstr=sprintf ("delete from t_group_server_login where loginid=%u", $loginid);
		$this->db->update($sqlstr);

		$sqlstr=sprintf ("delete from t_server_login where loginid=%u", $loginid);
		$this->db->update($sqlstr);
	}


	function user_add($username ){
		$sqlstr=sprintf ("insert into t_user values('%s',%u,1) ",
				$username,time(NULL) );
		$this->db->update($sqlstr);
	}

	function user_del($username ){
		$sqlstr=sprintf ("delete from t_group_user where username ='%s'",
				$username );
		$this->db->update($sqlstr);
		$sqlstr=sprintf ("delete from t_user where username ='%s'",
				$username );
		$this->db->update($sqlstr);
	}

	function user_set_useflag($username,$useflag ){
		$sqlstr=sprintf ("update t_user  set useflag=%u where username ='%s'",
				 $useflag,$username );
		$this->db->update($sqlstr);

	}

	function user_power_get_list($username){
		$sqlstr=sprintf ("select t4.ip,t4.port, t4.loginname ,t4.descstr, t5.groupname  from t_group_user t2, t_group_server_login t3, t_server_login t4,t_group t5 where  t2.groupid=t3.groupid and t2.groupid=t5.groupid and t3.loginid=t4.loginid and t2.username='%s' ", $username );
		//echo $sqlstr;
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()){
			$ls[]=$row;	
		}
		return $ls;
	}

	function user_login_get_list($opt_time,$username){
		if ($username==""){
			$name_fmt="true";
		}else{
			$name_fmt="username='$username' ";
		}

		$sqlstr=sprintf ("select id,username,starttime,endtime,loginip,logflie from t_user_login_log  where starttime>=%s and starttime < %s and %s",$opt_time ,  Caldate($opt_time,1 ),$name_fmt );
		//echo $sqlstr;
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()){
			$ls[]=$row;	
		}
		return $ls;
	}
	function get_session_user_input($login_session_id){
		$sqlstr="select  opttype , logtime  ,  cmdstr    from  t_user_opt_info where login_session_id=$login_session_id order by logtime";
		#echo $sqlstr;
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$ls[]=$row;	
		}
		return $ls;
	}
	function get_user_input($logtime,$username){
		if ($username==""){
			$name_fmt="true";
		}else{
			$name_fmt="username='$username' ";
		}

		$sqlstr=sprintf( "select login_session_id, username, opttype , logtime  ,  cmdstr    from  t_user_opt_info where logtime>='%s' and logtime <'%s'  and %s order by logtime", 
			$logtime,Caldate($logtime,1 ), $name_fmt );
		//echo $sqlstr;
		$ls=array() ;
		$result = $this->db->query($sqlstr);
		while ($row = $result->fetch_row()) {
			$ls[]=$row;	
		}
		return $ls;
	}

} 

#$db=Cserver_log::getMyiface();
#print_r ($db->get_user_input("20091104","login" ));

?>
