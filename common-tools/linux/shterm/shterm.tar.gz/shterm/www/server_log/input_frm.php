<?php
	require_once("../pub/proto.php");
	require_once("../pub/comm.php");
if ( ! login_check() ){
	return ;
}

?>
	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="../pub/jquery-1.3.2.js" type="text/javascript"></script>
<script type="text/javascript">
function div_hide(divname ){
	p_item=$('#'+divname);  
	p_item.hide();
}

function div_show(divname ){
	p_item=$('#'+divname);  
	p_item.show();
}

function change_opt( )
{
	var optlist=new Array();
	optlist[0]="id_base_info";
	optlist[1]="id_user_login";
	optlist[2]="id_user_power";
	for(i=0;i<optlist.length;i++ ){
		div_hide(optlist[i] );
	}

	var select_value=$("#optid").val();
	switch (select_value ){
		case "1":
    		window.parent.frames['show_frm'].location.href="./base_info.php";
			break;
		case "2":
			div_show("id_user_power" );
			break;
		case "3":
			div_show("id_user_login" );
			break;
	}
}
</script>

<html>
<body bgcolor=f6e1e1 >
<div  align ="width" >
	<table width="100%">
	<tr>
	<td >
	<select id='optid' onchange="change_opt();" >
	    <option value=1 selected > 基础信息
	    <option value=2> 用户权限查询
	    <option value=3 > 登入记录查询
	</select>
	
	<td COLSPAN=4>
	
	<div id="id_user_login" style='display:none;' >	
		<form    method="get" action="./user_login.php" target="show_frm" >
		<font color="red" > 日期:</font>
		<input type="text"  name="id_login_time"  size=8
		value="<?php echo date("Ymd"); ?>" />
		<font color="red" > 用户:</font>
		<input type="text"  name="username" size=4 value="" />
				<input type="submit" name="submitted" value="查询">
		</form>
	</div>


	<div id="id_user_power" style='display:none;' >	
		<form    method="get" action="./user_power.php" target="show_frm" >
		<font color="red" > 用户: </font>
		<input type="text" size=4 name="username" style='font-size:16;' 
		value="" />
				<input type="submit" name="submitted" style='font-size:16;' value="查询">
		</form>
	</div>

	</tr>
	</table>

</div>
</body>
</html>

