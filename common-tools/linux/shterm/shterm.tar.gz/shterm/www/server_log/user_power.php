<?php
	require_once("../pub/comm.php");
	require_once("server_log.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
</head>
<SCRIPT LANGUAGE="JavaScript" src="../pub/pub.js"></SCRIPT>
<script src="../pub/jquery-1.3.2.js" type="text/javascript"></script>
<script type="text/javascript">
function div_swap_show(divname ){
	p_item=$('#'+divname);  
	if (p_item.css('display')=='none'){
		p_item.show();
	}else{
		p_item.hide();
	}

}

</script>
<body >
<div align=center>
<?php
    $username=$_GET["username"];
	$db=Cserver_log::getMyiface();
	$user_list=$db->user_power_get_list($username);
	
	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >用户:$username:可登入机器
		<tr ><th>ID<th>ip<th>端口<th>用户名<th>描述<th>权限所在组</tr>
		";
	for ($i=0;$i<count($user_list);$i++){
		printf( "<tr > 
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			</tr>",
			$i,
			$user_list[$i][0],
			$user_list[$i][1],
			$user_list[$i][2],
			$user_list[$i][3],
			$user_list[$i][4],
			$user_list[$i][5]
	   	);
	}
	echo "</table>";



?>

</div>
</body>
</html>
