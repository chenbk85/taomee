<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html>
<body bgcolor=f6e1e1 >
<div  align ="center" >
<br>


<?php
	require_once("../pub/proto.php");
	require_once("../pub/comm.php");
	$adminid=$_POST["adminid"];
	$passwd=$_POST["passwd"];
		
	$proto=new Cproto($payserip,$payserport);
	if ($adminid) //login
	{
		$ret_arr=$proto->su_login_by_id($adminid,md5($passwd) );
		if ($ret_arr["result"]==0){

			$loginflag=true; 
			$adminflag=$ret_arr["flag"]; 
			echo "<script language=javascript>window.parent.parent.frames['menu_frm'].location.reload();</script>登入成功..";
		}else{
			$loginflag=false; 
		}

		$_SESSION["nick"] = $ret_arr["nick"];
		$_SESSION["adminid"] = $adminid ;
		$_SESSION["loginflag"]=$loginflag;
		$_SESSION["adminflag"]=$adminflag;
		for ($i=0;$i<count($flag_list);$i++){
			$flagitem=$flag_list[$i];
			if (($adminflag& $flagitem[0])>0){
				$_SESSION[$flagitem[1]]=true;
			}else{
				$_SESSION[$flagitem[1]]=false;
			}
		}
	}

	if (!$loginflag){
?>
		<form method="post" action="" target="head_frm" >
		<font color="red" > 管理员号：&emsp;  &emsp;  </font>
		<input type="text" size=15 name="adminid" value="" />
		<font color="red" > 密码：&emsp;  &emsp;  </font>
		<input type="password" size=15 name="passwd" value="" />
				<input type="submit" name="submitted" value="登入">
		</form>
<?php
	}
?>
</div>
</body>
</html>

