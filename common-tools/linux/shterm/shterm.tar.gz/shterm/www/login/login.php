<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
</head>
<body>
<br>
<br>
<br>
<br>


<div id="wrap" >
<br>
<br>
<br>
<br>

<?php
	require_once("../pub/proto.php");
	require_once("../pub/comm.php");
	require_once("./su_power_def.php");
	$adminid=$_POST["adminid"];
	$passwd=$_POST["passwd"];

	if ($adminid ){
		$proto=new Cproto($payserip,$payserport);

		$ret_arr=$proto->admin_login($adminid,md5($passwd) );
		if ($ret_arr["result"]==0){
			$loginflag=true; 
			$adminflag=$ret_arr["flag"]; 
			$msg="<script language=javascript>window.parent.menu_frm.location.reload();</script>登入成功..";

			$adminid=$ret_arr["userid"];
			$_SESSION["nick"] = $ret_arr["nick"];
			$_SESSION["adminid"] = $adminid ;


			//设置
			for ($i=0;$i<$ret_arr["count"];$i++){
					//echo "$i";
				if ($su_power_def[$ret_arr["powerid_$i"]]){
					//echo $v[1];
			   		$su_power_def[$ret_arr["powerid_$i"]][10]=1;
				}
			}
			foreach ($su_power_def as  $k=>$v){
				if ($v[10]==1){
					//echo $v[1];
					$_SESSION[$v[1]]=true;	
				}else{
					$_SESSION[$v[1]]=false;	
				}
			}
			if ($_SESSION["power_flag_change_user"] ){
				$_SESSION["power_flag_report"] =true; 
			}	
			/*
			if ($_SESSION["power_flag_report"] ){
				$_SESSION["power_flag_send_user_msg"] =true; 
			}	
			*/



	
			//得到admin列表
			$admin_list=array();
			$ret_arr=$proto->admin_get_adminlist(0);
			if ($ret_arr["result"]==0){
			//echo "count:".$ret_arr["count"];
				for ($i=0;$i<$ret_arr["count"];$i++){
					$admin_list[$ret_arr["adminid_$i"]]=
						array($ret_arr["adminid_$i"], $ret_arr["nick_$i"] );
				}
			}

			//echo "====".count ($admin_list );
			$_SESSION["admin_list"]=serialize($admin_list);
		}else{
			$loginflag=false; 
			if ($ret_arr["result"]==1107)  {
				$errmsg="被禁用了";
			}else if ($ret_arr["result"]==1103)  {
				$errmsg="密码验正失败";
			}else{
				$errmsg=$ret_arr["result"];
			}

			$msg="登入检正失败:$errmsg";
		}
		$_SESSION["loginflag"]=$loginflag;
			
		echo  "<div align=center> <font color=red size=4> $msg </font>  <div>";
	}else{
?>
		<div align=center> <font color=red size=4>客服后台登入</font>  <div>
		<form method="post" action=""  ><font size=4>
		<table >
		<tr> <td align=right>管理员号：<td><input type="text" size=10 name="adminid" value="" /></tr> 
		<tr><td align=right>密码：<td><input type="password" size=10 name="passwd" value="" /> </tr> 
		<tr><td colspan=2 align=center ><input type="submit" name="submitted" value="提交"/></tr>
		</table>
		</font>
		</form>
<?php
	}
?>
<br>
<br>
<br>
<br>


</div>
</body>
</html>
