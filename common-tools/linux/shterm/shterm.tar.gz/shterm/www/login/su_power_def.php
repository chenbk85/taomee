<?php

	//200000000-300000000:客服
	$su_power_def[200000000]=array(200000000,"power_flag_read", "基本数据查看." );
	$su_power_def[200000001]=array(200000001,"power_flag_send_user_msg", "回复用户　　." );
	$su_power_def[200000002]=array(200000002,"power_flag_change_user", "修改用户数据." );
	$su_power_def[200000003]=array(200000003,"power_flag_send_group_msg", "群发在线信息." );
	$su_power_def[200000004]=array(200000004,"power_flag_change_admin", "权限管理　　." );
	$su_power_def[200000005]=array(200000005,"power_flag_game_score_clean", "清空游戏列表." );
	$su_power_def[200000006]=array(200000006,"power_flag_stop_user", "客服：封停用户");
	$su_power_def[200000007]=array(200000007,"power_flag_clear_dustbin", "客服：清空垃圾箱");
	$su_power_def[200000008]=array(200000008,"power_flag_re_report", "客服：重复回复");
	$su_power_def[200000009]=array(200000009,"power_flag_set_email", "客服：重设邮箱");
	$su_power_def[200000010]=array(200000010,"power_flag_read_passwd", "客服：查看密码");
	$su_power_def[200000011]=array(200000011,"power_flag_pp", "客服：PP");
	$su_power_def[200000012]=array(200000012,"power_flag_report",  "客服：用户举报处理");

?>
