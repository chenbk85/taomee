<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
</head>
<body>
<br>
<br>
<br>
<br>


<div id="wrap" >
<br>
<br>
<br>
<br>

<?php
	require_once("../pub/proto.php");
	require_once("../pub/comm.php");
	$adminid=$_POST["adminid"];

	$oldpasswd=$_POST["oldpasswd"];
	$newpasswd1=$_POST["newpasswd1"];
	$newpasswd2=$_POST["newpasswd2"];
		
	$proto=new Cproto($payserip,$payserport);
	if ($adminid) //change passwd
	{
		if ($newpasswd1!=$newpasswd2) {
			$msg= "确认密码失败";
		}else{
			$ret_arr=$proto->su_change_passwd($adminid,md5($oldpasswd),
					md5($newpasswd2) );
			if ($ret_arr["result"]==0 )	{
				$msg= "修改成功 ";
			}else{
				$msg="修改失败";
			}
		}	
	}
	if ($adminid ){
		echo  "<div align=center> <font color=red size=4> $msg </font>  <div>";
	}else{
?>
		<div align=center> <font color=red size=4>	修改密码  </font>  <div>
		<form method="post" action=""  ><font size=4>
		管理员号：<input type="text" size=10 name="adminid" value="<?php
		        echo $_SESSION["adminid"]; ?>" /> <br>
		旧密码：&nbsp;&nbsp;&nbsp;<input type="password" size=10 name="oldpasswd" value="" /> <br>
		新密码：&nbsp;&nbsp;&nbsp;<input type="password" size=10 name="newpasswd1" value="" /> <br>
		确认：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" size=10 name="newpasswd2" value="" /> <br>
		<input type="submit" name="submitted" value="修改"/>
		</font>
		</form>
<?php
	}
?>
<br>
<br>
<br>
<br>


</div>
</body>
</html>
