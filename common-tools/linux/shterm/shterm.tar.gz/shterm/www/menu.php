<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
</head>
<body >
<div id="wrap" align=center> <font size=5>  
<?php
	function get_item_fmt ($url,$name){
	echo "<font size=4><a href='$url' target='sub_frm' >$name</a> </font><br>";
	}	

	require_once("pub/comm.php");
	$adminid= 	$_SESSION["adminid"];
	$nick= 	$_SESSION["nick"];
	$loginflag= $_SESSION["loginflag"];

	if ($loginflag==true) {
		echo   $adminid. ":".$nick.":".$_SESSION["adminflag"]; 
	}else echo "<font color=red> 没有登入</font>";
?>
</font>
</div>

<?php
    get_item_fmt("./login/login.php", "管理员登入" );

	//PP
	if	(admin_check("power_flag_pp")){
	    	get_item_fmt("./server_log", "用户登入线网管理" );
	}




	if ($loginflag==true){
		//if ($test_server==false)
			//get_item_fmt("./usermsg/dindan.php", "订单查询" );
		//get_item_fmt("./usermsg/user_talk.php", "聊天记录查询" );
		get_item_fmt("./admin_all/change_passwd.php", "管理员修改密码" );
	}

?>
</body>
</html>
