<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
</head>
<SCRIPT LANGUAGE="JavaScript" src="../pub/pub.js"></SCRIPT>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
<script src="../pub/jquery-1.3.2.js" type="text/javascript"></script>
<body  align=left>


<?php
	$filename=$_GET['filename'];
	$login_session_id=$_GET['login_session_id'];
	require_once("server_log.php");
	require_once("input_convert.php");

	$db=Cserver_log::getMyiface();
	$user_list=$db->get_session_user_input($login_session_id );

	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >用户操作
		<tr ><th>类型<th>操作时间<th>命令输入 </tr>
		";

	for ($i=0;$i<count($user_list);$i++){
		$opttype=$user_list[$i][0];
		switch ($opttype ){
			case 1:
				 $user_list[$i][2]=input_convert($user_list[$i][2]);//hex->input
		};
		
		printf( "<tr > 
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			</tr>",
			 $opttype_conf[$opttype],
			$user_list[$i][1],
			$user_list[$i][2]
	   	);
	}
	echo "</table>";
	
echo "<div align=left  >";

//---------------------------------------------
		
 	$fp=popen  ( "sed 's/\o033[^m]*m//g' $filename" ,"r" );

	echo "<font size=3  color=black ><pre>";
	 while(!feof($fp))
    {
        echo fread($fp, 1024);
        flush();
    }
	echo "   </pre></font>";
    fclose($fp); 

echo "</div>";
?>

</body>
</html>
