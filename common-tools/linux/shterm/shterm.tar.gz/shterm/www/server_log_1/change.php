<?php
require_once("../pub/comm.php");
require_once("server_log.php");


$R=$_REQUEST;
$cmd=$R["cmd"];
$db=Cserver_log::getMyiface();

switch ($cmd){
	case 1:
		$db->user_add($R["username"]);
		break;
	case 2:
		$db->user_del($R["username"]);
		break;
	case 3:
		$db->group_add($R["groupname"]);
		break;

	case 4:
		$db->group_del($R["groupid"]);
		break;
	case 5:
		$db->server_login_add( $R["ip"],$R["port"], $R["loginname"], 
				$R["loginpasswd"], $R["descstr"]);
		break;
	case 6:
		$db->server_login_del($R["loginid"]);
		break;
	case 7:
		if ($R["opt"]==0){
			$db->group_user_del($R["groupid"],$R["username"]);
		}else{
			$db->group_user_add($R["groupid"],$R["username"]);
		}
		break;
	case 8:
		if ($R["opt"]==0){
			$db->group_server_login_del($R["groupid"],$R["loginid"]);
		}else{
			$db->group_server_login_add($R["groupid"],$R["loginid"]);
		}
		break;

	case 9:
		$db->server_login_change_passwd($R["loginid"],$R["loginpasswd"]);
		break;

	case 10:
		$db->server_login_change_descstr($R["loginid"],$R["descstr"]);
		break;

	case 20:
	//	$ret_arr=$proto->roominfo_set_info($R["userid"], $R["candy_count"], $R["prop_count"], $R["flag"]);
		break;
	default:
		$ret_arr=$R;

}
print_r ($R);
?>
