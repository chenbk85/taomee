<?php
	require_once("../pub/comm.php");
	require_once("server_log.php");
	if ( ! login_check() ){
		get_std_page();
		exit;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<link id="themestyle" rel="stylesheet" type="text/css" href="./css.css">
</head>
<SCRIPT LANGUAGE="JavaScript" src="../pub/pub.js"></SCRIPT>
<script src="../pub/jquery-1.3.2.js" type="text/javascript"></script>
<script type="text/javascript">

function div_swap_show(divname ){
	p_item=$('#'+divname);  
	if (p_item.css('display')=='none'){
		p_item.show();
	}else{
		p_item.hide();
	}

}

function change_group_server_login_opt(i, groupid )
{
	var select_value=$("#group_server_login_opt_"+i).val();
	select_server_login_list(i,groupid,select_value );
}

function group_del(groupid){
	$.post('./change.php',{
			'cmd':4,
			'groupid':groupid
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}
function server_login_del(loginid){
	$.post('./change.php',{
			'cmd':6,
			'loginid':loginid
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}

function server_login_change_descstr(loginid,descstr){
	$.post('./change.php',{
			'cmd':10,
			'loginid':loginid,
			'descstr':descstr
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}



function server_login_change_passwd(loginid,loginpasswd,re_loginpasswd){
	if (loginpasswd!=re_loginpasswd) {
		alert("密码输入不一致" );
		return false;
	}

	$.post('./change.php',{
			'cmd':9,
			'loginid':loginid,
			'loginpasswd':loginpasswd
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}


function server_login_add(ip,port, loginname, loginpasswd,re_loginpasswd,descstr ){
	if (loginpasswd!=re_loginpasswd) {
		alert("密码输入不一致" );
		return false;
	}

	$.post('./change.php',{
			'cmd':5,
			'ip':ip,
			'port':port,
			'loginname':loginname,
			'loginpasswd':loginpasswd,
			'descstr':descstr
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}

function group_add(groupname){
	$.post('./change.php',{
			'cmd':3,
			'groupname':groupname
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}

function select_server_login_list(i, groupid,in_flag){
	$.post('./select_server_login_list.php',{
			'groupid':groupid,
			'in_flag':in_flag,
			'index':i
			},function(result){
			var itemlist =result.split(":");

			//document.location.reload(true);
	});
	return false; 
}
function group_user_opt(groupid,opt, username){
	$.post('./change.php',{
			'cmd':7,
			'groupid':groupid,
			'opt':opt,
			'username':username
			},function(result){
	//		alert(result);
			document.location.reload(true);
	});
	return false; 
}
function group_server_login_opt(groupid,opt, loginid){
	$.post('./change.php',{
			'cmd':8,
			'groupid':groupid,
			'opt':opt,
			'loginid':loginid
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}



function user_add(username){
	$.post('./change.php',{
			'cmd':1,
			'username':username
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}
function user_del(username){
	$.post('./change.php',{
			'cmd':2,
			'username':username
			},function(result){
			//alert(result);
			document.location.reload(true);
	});
	return false; 
}


</script>
<body >
<div align=center>
<?php

	$db=Cserver_log::getMyiface();
	$user_list=$db->get_user_list();
	$group_list=$db->get_group_list();
	$server_login_list=$db->get_server_login_list();
	$group_user_list=$db->get_group_user_list();
	$group_server_login_list=$db->get_group_server_login_list();
	
	$group_user_map= array();
	foreach($group_user_list as $group_user ){
		$groupid=$group_user[0];
		if ( ! $group_user_map[$groupid ] ){
			$group_user_map[$groupid] =array( );	
		}
		$group_user_map[$groupid][]=$group_user[1];
	}

	$group_server_login_map= array();
	foreach($group_server_login_list as $group_user ){
		$groupid=$group_user[0];
		if ( ! $group_server_login_map[$groupid ] ){
			$group_server_login_map[$groupid] =array( );	
		}
		$loginid=$group_user[1];	
		$group_server_login_map[$groupid][]=
			"[<font color=red>$loginid</font>]".$server_login_list[$loginid][3]."@".$server_login_list[$loginid][1] ;
	}
//	print_r( $group_server_login_map );




	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >组
			<a href='./l' onclick=\" div_swap_show('id_group_add');
				return false;  \" >增加</a>
				<span id='id_group_add'  style='display:none;'  > 名字
				<input type=text id='groupname' size=4 value='' ></input> 
				</input> 
				<a href='./l' onclick =\"group_add($('#groupname').val());  return false;\">提交</a>
			   	</span>
	
		</caption>
		<tr ><th>组名
		<th>成员:
		<th >可登入机器:
		<th >删除
		<th >编辑
		";
	$i=0;
	foreach ($group_list as $group){
		$groupid=$group[0];
		printf( "<tr > 
			<td class=\"spec\" >%s:%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td><a href='./l' onclick=\" if (re_check('要删除:%s?')) group_del(%s)  ; return false;  \" >删除</a>
			<td> <a href='./l' onclick=\" div_swap_show('id_group_edit_$i');
				return false;  \" >编辑</a>
			</tr>
			",
			$groupid,$group[1], 
			get_arr_fmt_str($group_user_map[$groupid]),
			get_arr_fmt_str($group_server_login_map[$groupid]),
			$group[1],$groupid

	   	);
		print "<tr id='id_group_edit_$i' style='display:none;'  >
			<td>

			<td>
				<select id='group_user_opt_$i'  >
				    <option value=0> 移除
				    <option value=1 selected> 增加
				</select>
				<input type=text id='group_username_$i' size=4 value='' ></input> 
				<a href='./l' onclick =\" group_user_opt( $groupid, 
				$('#group_user_opt_$i').val(), $('#group_username_$i').val());  return false;\">提交</a>
			<td>
				<select id='group_server_login_opt_$i'   >
				    <option value=0> 移除
				    <option value=1 selected> 增加
				</select> LOGIN_ID:
				<input type=text id='group_server_login_loginid_$i' size=4 value='' ></input> 
				<a href='./l' onclick =\"group_server_login_opt ( $groupid, 
				$('#group_server_login_opt_$i').val(), $('#group_server_login_loginid_$i').val());  return false;\">提交</a>
			
			<td>
			</tr>";
		$i++;
	}
	echo "</table>";



	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >用户 
			<a href='./l' onclick=\" div_swap_show('id_user_add');
				return false;  \" >增加</a>
				<span id='id_user_add'  style='display:none;'  > 名字
				<input type=text id='username' size=4 value='' ></input> 
				</input> 
				<a href='./l' onclick =\"user_add($('#username').val());  return false;\">提交</a>
			   	</span>
		</caption>
		<tr ><th>编号<th>用户名 <th>创建时间<th>是否可用<th>删除</tr>
		";
	for ($i=0;$i<count($user_list);$i++){
		printf( "<tr > 
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >
			<a href='./l' onclick=\" if (re_check('要删除:%s?')) user_del('%s')  ; return false;  \" >删除</a>
			</tr>
			",
			$i,$user_list[$i][0],
			get_date_from_time_t($user_list[$i][1]),
			$user_list[$i][2],
			$user_list[$i][0],
			$user_list[$i][0]
	   	);
	}
	echo "</table>";

	echo " <table id=\"mytable\" cellspacing=\"0\"  >
		<caption >服务器登入信息 <a href='./l' onclick=\" div_swap_show('id_server_login_add');
				return false;  \" >增加</a>

		</caption>
		<tr ><th>LOGIN_ID<th>IP<th>端口<th>用户名<th>密码<th>说明<th>删除<th>编辑</tr>
		";
	print "<tr id='id_server_login_add' style='display:none;'  >
			<td>
			<td><input type=text id='id_ip' value='192.168.' size=10></input>
			<td><input type=text id='id_port' value='56000' size=10></input>
			<td><input type=text id='id_loginname' value='' size=6></input>
			<td><input type=password id='id_passwd' value='' size=6></input>
			    再输一次<input type=password id='id_repasswd' value='' size=6></input>
			<td><input type=text id='id_descstr' value='' size=12></input>
			<td><a href='./l' onclick =\" server_login_add(
			$('#id_ip').val(),
			$('#id_port').val(),
			$('#id_loginname').val(),
			$('#id_passwd').val(),
			$('#id_repasswd').val(),
			$('#id_descstr').val()
			);  return false;\">增加</a></tr>";


		$i=0;
		foreach($server_login_list as $server ){
		printf( "<tr > 
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s
			<td class=\"spec\" >%s

			<td><a href='./l' onclick=\" if (re_check('要删除编号为:%s的吗?')) server_login_del(%s)  ; return false;  \" >删除</a>
			<td> <a href='./l' onclick=\" div_swap_show('id_server_login_change_passwd_$i');
				return false;  \" >编辑</a>
			</tr>
			",
			$server[0],
			$server[1],
			$server[2],$server[3],
			$server[4],
			$server[5],
			$server[0],
			$server[0]
	   	);
	print "<tr id='id_server_login_change_passwd_$i' style='display:none;'  >
			<td>
			<td>
			<td>
			<td>
			<td>
			<input type=password id='id_ch_passwd_$i' value='' size=6></input>
			    再输一次<input type=password id='id_ch_repasswd_$i' value='' size=6></input>
			<a href='./l' onclick =\"server_login_change_passwd (
			{$server[0]},
			$('#id_ch_passwd_$i').val(),
			$('#id_ch_repasswd_$i').val()
			);  return false;\">提交</a>
			<td>
			<input type=text id='id_ch_descstr_$i' value='' size=6></input>
			<a href='./l' onclick =\"server_login_change_descstr (
			{$server[0]},
			$('#id_ch_descstr_$i').val()
			);  return false;\">提交</a>
			

			<td> <td></tr>";


		$i++;
	}
	echo "</table>";




?>
</div>
</body>
</html>
