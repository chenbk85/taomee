<?php
	require_once("proto.php");
	require_once("item.php");
	function get_flag($v ){
		if ($com_0_att_arr[$k]){
			return '是';
		}else{
			return '否';
		}

	}
	function get_attirelist($userid ){
		$att_arr=array();
		//得到物品	
		$proto=new Cproto("10.1.1.5",21001);
		$attirelist[0]=$proto->user_get_attire_list($userid,0, 0 );
		$attirelist[1]=$proto->user_get_attire_list($userid,1, 0 );
		$attirelist[2]=$proto->user_get_attire_list($userid,2, 0 );
		for ($i=0;$i<(count($attirelist));$i++ )	{
			$list=$attirelist[$i];
			$count=$list["count"];
			for ($j=0;$j<$count;$j++ ){
				$att_arr[$list["attireid_$j"]]=$list["count_$j"];
			//	echo $list["attireid_$j"], " ",	$list["count_$j"] ,   "\n"; 	
			}
		}
		return $att_arr;
	}
	$comm_0_userid= 3635743;
	$comm_1_userid= 66548318;
	$vip_userid=7741246;

	$com_0_att_arr=get_attirelist($comm_0_userid );
	$com_1_att_arr=get_attirelist($comm_1_userid );
	$vip_att_arr=get_attirelist($vip_userid );
	foreach ($vip_att_arr as $k => $v ){
		$c_0=$com_0_att_arr[$k];
		if(!$c_0) $c_0=0;
		$c_1=$com_1_att_arr[$k];
		if(!$c_1) $c_1=0;
		echo $k," ",$c_0 ," ",$c_1 ," ", $v ," ", $item_list[$k] , "\n" ;
	}
?>

