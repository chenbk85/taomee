<?php
	require_once("mysqlinterface.php");

class Cuser_submit{
		var $myiface;
	function __construct($ip,$user,$passwd,$dbname  ){
		$this->myiface= new MysqlInterface($ip,$user , $passwd,$dbname );	
	}
	function __destruct(){

	}

	function writing_get_list( $opt_arr )
	{
		$wheresql=$this->writing_get_list_where($opt_arr);
		$startpageid=$opt_arr["startpageid"];
		$pagecount=$opt_arr["pagecount"];
		$opttype=$opt_arr["opttype"];

		$order_str="";
		switch( $opttype  ) {
			case 1:
				break;
			case 2:
				$order_str="order by msgid desc";
				break;
			case 3:
				$order_str="order by replytime desc";
				break;
		}



		$sql_str="select msgid,from_unixtime(logtime ), msgtype, msgstore,userid,msg,".
			"replyid, from_unixtime(replytime),replymsg from t_writing  ".
			"where $wheresql $order_str  limit $startpageid , $pagecount ";
		$result = $this->myiface->query($sql_str);
		return $result;
	}

	function writing_get_list_where( $opt_arr )
	{
		$opttype=$opt_arr["opttype"];
		$startdate=$opt_arr["startdate"];
		$enddate=$opt_arr["enddate"];
		$msgtype=$opt_arr["msgtype"];
		$msgstore=$opt_arr["msgstore"];
		$userid=$opt_arr["userid"];
		$replyid=$opt_arr["replyid"];
		$searchkey=$opt_arr["searchkey"];
		
		$sql_str="";

		switch( $opttype  ) {
			case 1:	//得到正常消息
				if ($msgtype == 0 )  {
					$msgtype_str="true";
				}else{
					$msgtype_str=" msgtype=$msgtype ";
				}
				if ($msgtype == 0 )  {
					$msgtype_str="true";
				}else{
					$msgtype_str=" msgtype=$msgtype ";
				}
				if ( $searchkey== "" )  {
					$searchkey_str="true";
				}else{
					$searchkey_str=" msg like '%$searchkey%' ";
				}

				$sql_str.=" logtime>=$startdate  and logtime< $enddate and ".
					" $msgtype_str and  msgstore=$msgstore and  $searchkey_str "; 
				break;
			case 2://通过userid 查
				$sql_str="userid=$userid  ";
				break;
			case 3://查询客服人员的回复
				$sql_str=" logtime>=$startdate  and logtime< $enddate and replyid=$replyid ";
		}
		return $sql_str;

} 	


};

$us=new Cuser_submit("10.1.1.5","root","ta0mee","PP_SUBMIT_DB");
$opt_arr["opttype"]=2;
$opt_arr["userid"]=8291010;

$opt_arr["startpageid"]=0;
$opt_arr["pagecount"]=10;

$us->writing_get_list($opt_arr );
	
?>
