<?php
if ($_SERVER["HTTP_HOST"]== "114.80.98.39" ){
	//在正式环境中..
	$test_server=false;
	$with_pp_flag=true;
}else{
	//在测试环境..
	$tw_flag=true;
	$test_server=true;
	$with_pp_flag=true;
}

if (!$tw_flag ){
	$str_1="米琪";
	$str_2="亲爱的";
	$str_3="公民管理处";
	$str_10="您的投稿已经通过审核，投稿号：%s，赶快去看一下吧！";
	$str_11="您弹的乐曲已经通过审核，乐曲号：%s，赶快去听一下吧！";
	$str_12="您的涂鸦已经通过审核，涂鸦号：%s，赶快去看一下吧！";
}else{
	//是台湾版本
	$str_1="米琪";
	$str_2="亲爱的";
	$str_3="公民管理处";
	$str_10="您的投稿已经通过审核，投稿号：%s，赶快去看一下吧！";
	$str_11="您弹的乐曲已经通过审核，乐曲号：%s，赶快去听一下吧！";
	$str_12="您的涂鸦已经通过审核，涂鸦号：%s，赶快去看一下吧！";
}

if ($test_server){
	//db
	$payserip="10.1.1.5";
	$payserport=22001;

	$pp_submit_ip="10.1.1.5";
	$pp_submit_port=16001;

	//switch
	$switchip="10.1.1.7";
	$switchport=4431;

	//talkdb
	$talkip="10.1.1.7";
	$talkuser="root";
	$talkpasswd="ta0mee";

	$pp_talkip="10.1.1.5";
	$pp_talkuser="root";
	$pp_talkpasswd="ta0mee";



	//查看客服修改的记录
	$suchange_ip="10.1.1.7";
	$suchange_user="root";
	$suchange_passwd="ta0mee";



	$pic_php_server="http://10.1.1.7:81/cgi-bin/gate/review_wall.php";


    $serverlist[1]=array("AndyTest");
    $serverlist[2]=array("2");
    $serverlist[3]=array("3");
    $serverlist[4]=array("4");
    $serverlist[5]=array("5");
    $serverlist[6]=array("6");
    $serverlist[7]=array("7");
    $serverlist[8]=array("测试版本");
    $serverlist[9]=array("测试版本");
}else{
	//db
	$payserip="192.168.0.39";
	$payserport=21001;

	$pp_submit_ip="192.168.2.82";
	$pp_submit_port=16001;


	//switch
	$switchip="192.168.0.17";
	$switchport=4431;

    //talk
	$talkip="192.168.0.53";
	$talkuser="chatlog";
	$talkpasswd="chatlog@TAOMEE";

	//查看客服修改的记录
	$suchange_ip="localhost";
	$suchange_user="root";
	$suchange_passwd="ta0mee";


	//pic_php_server
	$pic_php_server="http://192.168.0.80:80/cgi-bin/gate/review_wall.php";


    $serverlist[1]=array("发明屋");
    $serverlist[2]=array("神秘湖");
    $serverlist[3]=array("爱心教堂");
    $serverlist[4]=array("淘淘乐街");
    $serverlist[5]=array("阳光牧场");
    $serverlist[6]=array("开心农场");
    $serverlist[7]=array("摩尔拉雅山");
}
?>

