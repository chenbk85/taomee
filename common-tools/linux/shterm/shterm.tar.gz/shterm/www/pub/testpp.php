<?php
	require_once("proto.php");
	require_once("comm.php");

/*
//	$proto=new Cproto("192.168.0.39",21001 );
	$proto=new Cproto("10.1.1.5",21001 );
	//$proto=new Cproto($payserip , $payserport );
	for ($i=0; $i<100;$i++ ){
		//$userid=20000+($i+1)*6;
		$userid=20000+$i;
		$retarr=$proto->user_test($userid);
		printf("%s:%d:%s\n", $userid,$retarr["result"] ,$retarr["sermsg"]);
	}
*/

	$iplist=array ( 
		76,78, 77,82,83,84,92,93,94,95,96,97
	);

	foreach ( $iplist as $ip ){
		$proto=new Cproto("192.168.2.$ip",16001 );
		$retarr=$proto->user_test($userid);
		printf("%d:%d:%s\n", $ip ,$retarr["result"] ,$retarr["sermsg"]);
	}

?>
