<?php
	require_once("proto.php");
	require_once("comm.php");
    $proto=new Cproto("192.168.0.39",21001);
    $arr= $proto->userinfo_get_info_all($argv[1] );
    print $argv[1] .":". bin2hex(  $arr["passwd"])."\n";
?>

