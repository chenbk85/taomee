<?php
	require_once("comm.php");
	require_once("mysqlinterface.php");
	$myiface= new MysqlInterface($talkip,$talkuser , $talkpasswd, "");	
	$userid=$_GET["userid"];
	$userid=50096;

	$dbid=$userid%100;	
	$sqlstr_pre=sprintf ("select userid,loginflag,time,onlineid,ip  from LOGIN_DB.t_login_log_%02d",$dbid);

	$sqlstr=$sqlstr_pre.  " where  userid=$userid ";
	#echo $sqlstr;
	$result = $myiface->query($sqlstr);
	
	$i=0;
	while ($row = $result->fetch_row()) {
		$row[2]=get_date_from_time_t($row[2]);
		$row[4]=long2ip($row[4]);

		echo  $row[0]."\t".$row[1]."\t".$row[2]."\t".$row[3]."\t".$row[4]."\n" ;
	}
	$result->free();

?>
