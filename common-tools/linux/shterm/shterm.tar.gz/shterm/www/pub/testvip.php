<?php

	require_once("proto.php");
	//require_once("send_passwd_email.php");

	$proto=new Cproto("10.1.1.5",11008 );
	print_r ($proto->user_set_vip_flag(50134,1));
	//print_r ($proto->user_set_vip_flag(20066,0));

?>
