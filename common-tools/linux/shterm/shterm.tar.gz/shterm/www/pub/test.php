<?php
	require_once("proto.php");
	require_once("comm.php");

/*
//	$proto=new Cproto("192.168.0.39",21001 );
	$proto=new Cproto("10.1.1.5",21001 );
	//$proto=new Cproto($payserip , $payserport );
	for ($i=0; $i<100;$i++ ){
		//$userid=20000+($i+1)*6;
		$userid=20000+$i;
		$retarr=$proto->user_test($userid);
		printf("%s:%d:%s\n", $userid,$retarr["result"] ,$retarr["sermsg"]);
	}
*/

	$iplist=array ( 
		3,5,30,31,33,34,43,44,67,68,69,70,71,72,73,79,40,62,32,41,61,54,55,4,59,42,
		96,97,98,99,100,102,101,104,151
	);

	foreach ( $iplist as $ip ){
		$proto=new Cproto("192.168.0.$ip",11001 );
		$retarr=$proto->user_test($userid);
		printf("%d:%d:%s\n", $ip ,$retarr["result"] ,$retarr["sermsg"]);
	}

?>
