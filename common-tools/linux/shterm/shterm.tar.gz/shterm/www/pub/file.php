<?php
    require_once("proto.php");
    $switchip="10.1.1.5";
    $switchport=4431;

    $proto=new Cproto("10.1.1.5",21001);

    $fp=fopen( $argv[1]  ,"r");
    $i=0;
    while (! feof ($fp ) ) {
        $userid=fgets($fp );
        $arr=$proto->user_add_jy_attire($userid,1220071,1,1 );
        $i++;
        if ($i%100==0){
            echo "$i\n";
        }
    }
?>
