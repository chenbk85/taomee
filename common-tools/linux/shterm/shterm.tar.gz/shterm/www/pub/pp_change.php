<?php
	require_once("proto.php");
	require_once("comm.php");
	$proto=new Cproto("10.1.1.5",22001 );
	print_r ($proto->pp_taskday_clean_by_userid(12145219));
	print_r ($proto->pp_taskday_clean_by_userid(9893408));
	
?>
