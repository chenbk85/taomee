<?php

class socket{
	//private:
	var $socket; //socket 句柄
	//var $debug = 1;
	function __construct( $payserip,$payserport){
		$address = gethostbyname($payserip );
		if (($this->socket = socket_create(AF_INET,SOCK_STREAM,SOL_TCP))< 0 )
		{
			trigger_error("Couldn't create socket: " . socket_strerror(socket_last_error()) . "\n");
		}	
		$result = socket_connect($this->socket,$address,$payserport );
	}
	function log_msg($msg){
		global $_SESSION;
		$log_pkg_arr=@unpack("Lproto_len/Lproto_id/Scommandid/Lresult/Luserid",$msg);
		if ( ($log_pkg_arr["commandid"] & 0x0100) ==0x0100) {
			dbg_log( $_SESSION["adminid"].":".  dechex($log_pkg_arr["commandid"] ).
					":".$log_pkg_arr["userid"].":".bin2hex($msg));
		}
	}

	function sendmsg($msg){
		//$this->log_msg($msg);
		socket_write($this->socket,$msg, strlen($msg) );
		$buf= socket_read($this->socket,4096);
		$pkg_arr=@unpack("Lproto_len",$buf);
		$proto_len= $pkg_arr["proto_len"];
		//echo $proto_len;
		while ($proto_len!=strlen($buf) ){
			$buf .=	socket_read($this->socket,4096);
		}	
		return $buf;
	}
	function sendmsg_without_returnmsg($msg){
		//$this->log_msg($msg);
		$result=socket_write($this->socket,$msg, strlen($msg) );
		if ($result){
			return array("result"=>0);
		}else
			return array("result"=>1003);
	}

	function close(){
		socket_close($this->socket);
	}
	function __destruct(){
	}
} 
//日志消息
function    dbg_log($word){
    $fp = fopen("/tmp/sms_log" , "a");
    flock($fp, LOCK_EX) ;
    fwrite($fp,strftime("%Y%m%d%H%I%S",time()).":".$word."\n");
    flock($fp, LOCK_UN);
    fclose($fp);
}

if ( $_GET["verify"]!="add6b4bb1b0d2f3f6d859eeab7f1eb4b" ){
	dbg_log("check verify err:" . $_GET["verify"] );
	exit;	
}

$sock=new socket("10.1.1.3",5000  );
$sendmsg= $_GET["telephone"] .",:".$_GET["message"] ;
if ( (! strstr($_GET["message"], "WARNING" )) && 
 		(! strstr($_GET["message"], "OK" ) ) 
		){
	$ret_arr=$sock->sendmsg_without_returnmsg( $sendmsg );
	dbg_log("send : " .  $_GET["telephone"] . ":" . $_GET["message"]. ":" . $ret_arr["result"]);
	if ( $ret_arr["result"] != 0 ){
				mail ("xcwenn@gmail.com", "10.1.1.3 halt", "10.1.1.3 halt");
	}
}else{
	dbg_log("WARNING no send:".$_GET["message"] );
}
