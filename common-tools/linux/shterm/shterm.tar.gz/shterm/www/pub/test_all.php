<?php
	require_once("proto.php");
	require_once("comm.php");
	$iplist[]=array ("bat_server","192.168.2.74",4001 );
	$iplist[]=array ("switch ","192.168.2.73",4431);
	$iplist[]=array ("switch ","192.168.0.17",4431);

	$iplist[]=array ("cache ","192.168.0.7",3200 );

	$flashlist[]=array ("game ","114.80.98.11",3001);
	$flashlist[]=array ("game ","114.80.98.11",3002);
	$flashlist[]=array ("game ","114.80.98.11",3003);
	$flashlist[]=array ("game ","114.80.98.11",3004);

	$flashlist[]=array ("game ","114.80.98.25",3001);
	$flashlist[]=array ("game ","114.80.98.25",3002);
	$flashlist[]=array ("game ","114.80.98.25",3003);
	$flashlist[]=array ("game ","114.80.98.25",3004);



	$flashlist[]=array ("login ","114.80.99.73",1863);
#	$flashlist[]=array ("login ","114.80.98.17",1863);

#	$flashlist[]=array ("reg ","114.80.98.7",1863);

	//得到online列表 
    $fp=fopen( "id_list_jim"  ,"r");
    while (! feof ($fp ) ) {
        $onlineinfo=fscanf($fp,"%s%s" );
		if ($onlineinfo){
			$flashlist[]=array ("online",$onlineinfo[0],$onlineinfo[1] );
		}
    }



	foreach ( $iplist as $ip_item ){
		$proto=new Cproto( $ip_item[1] ,$ip_item[2] );
		printf("%s:%s:%s:",$ip_item[0],$ip_item[1] ,$ip_item[2]  );
		$retarr=$proto->test_by_local();
		printf("%s\n",$retarr["result"] );
	}

	foreach ( $flashlist as $ip_item ){
		$proto=new Cproto( $ip_item[1] ,$ip_item[2] );
		printf("%s:%s:%s:",$ip_item[0],$ip_item[1] ,$ip_item[2]  );
		$retarr=$proto->test_by_flash();
		printf("%s\n", $retarr );
	}



?>
