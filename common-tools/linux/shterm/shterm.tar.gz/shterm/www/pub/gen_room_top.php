<?php
	require_once("mysqlinterface.php");
	require_once("proto.php");
	//dbproxy 的配置
	$proto_ip="10.1.1.5";
	$proto_port=21001;
	
	//mysql 连接的配置
	$proto_ip="10.1.1.5";
	$host_mysql_conf[0]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[1]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[2]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[3]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[4]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[5]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[6]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[7]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[8]=array("10.1.1.7","dbuser","ta0mee" );
	$host_mysql_conf[9]=array("10.1.1.7","dbuser","ta0mee" );

	//得到某一个表的前10
	function get_table_top($dbid,$tableid,$field_type ){
		global  $host_mysql_conf;
		$ret_arr=array();
		$my_conf=$host_mysql_conf[$dbid];
		$myiface= new MysqlInterface(
			   	$my_conf[0], $my_conf[1] ,$my_conf[2] , "");	
		$sqlstr="select room_id, $field_type from ROOMINFO_$dbid.t_roominfo_$tableid ".
			" order by  $field_type desc   limit 0,10 " ;

	//	$sqlstr="select room_id, $field_type from ROOMINFO_$dbid.t_roominfo_$tableid ".
	//		" limit 0,10 " ;
		echo $sqlstr. "\n";

		$result = $myiface->query($sqlstr );
		while ($row = $result->fetch_row()) {
			array_push( $ret_arr, array($row[0],$row[1] ));
		}
		$result->free();
		return $ret_arr;
	}

	//得到前10
	function get_top_10($field_type ){
		global $proto_ip , $proto_port ;
		$proto=new Cproto($proto_ip,$proto_port);
			
		$arr=array();
		for($dbid=0;$dbid<10;$dbid++ ){
			for($tableid=0;$tableid<10;$tableid++ ){
				$tmp_arr=get_table_top($dbid,$tableid,  $field_type );
				for($i=0;$i<count($tmp_arr ) ;$i++ ){
					array_push( $arr,$tmp_arr[$i] );
				}
			}
		}
		$score_arr=array();
		for($i=0;$i<count($arr ) ;$i++ ){
			array_push( $score_arr ,$arr[$i][1] );
		}
		sort($score_arr);
		$ret_arr=array();
		for($i=count($score_arr)-1; $i>=count($score_arr)-10; $i-- ){
			array_push( $ret_arr ,$score_arr[$i] );
		}
		$ret_arr=array_unique($ret_arr );
		$top_arr=array();
		foreach($ret_arr as $k ){
			foreach($arr as $item ){
				$userid=$item[0];
				$score=$item[1];
				if ( $score ==$k ){
					$pro_arr=$proto->user_get_nick($userid);
					$nick=$pro_arr["nick"];
					
		 			$nick=str_replace('"' ,"", $nick);
		            $nick=str_replace('\'' ,"", $nick);
		            $nick=str_replace('<' ,"", $nick);
		            $nick=str_replace('>' ,"", $nick);
		            $nick=str_replace('/' ,"", $nick);
			
					array_push( $top_arr ,array($userid,$score ,$nick ) );
				}
			}
		}
		return $top_arr;
		#print_r ($top_arr);
	}

	$top[0]=get_top_10("room_hot");
	$top[1]=get_top_10("weekhot");
	$top[2]=get_top_10("dayhot");
	
	#打印数据
	$logfile="/var/www/toplist/toplist.xml";
	$fp = fopen($logfile, "w");	

	fwrite($fp,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" );

	fwrite($fp,"<root>\n" );
	for($i=0;$i<=2;$i++){
		$itemcount=count($top[$i]);
		fwrite($fp,"\t<Hots type=\"$i\"  count=\"10\" >\n" );
		for ($j=0;$j<10;$j++){
			$item=$top[$i][$j];
			fwrite($fp,"\t\t<Hot UID=\"{$item[0]}\" Nick=\"{$item[2]}\" Val=\"{$item[1]}\"/>\n" );
		}
		fwrite($fp,"\t</Hots>\n" );
	}

	fwrite($fp,"</root>\n" );
	fclose($fp);


	//fwrite($fp,strftime("%Y%m%d%H%I%S",time()).":".$word."\n");



?>
