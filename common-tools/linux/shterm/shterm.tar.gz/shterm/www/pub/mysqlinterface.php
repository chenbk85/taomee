<?php
	function write_flag($msg){	
		$logfile="/tmp/test1_".date('Ymd');
		$fp = fopen($logfile, "a");
		flock($fp, LOCK_EX) ;
		fwrite($fp,$msg."\n" );
		flock($fp, LOCK_UN);
	}

	class MysqlInterface{
		var $conn; 
		public function __construct($ip,$u,$p,$db){
			  $this->conn= mysqli_connect($ip,$u,$p,$db);
		}
		public function query($sql){
			return  $this->conn->query($sql, MYSQLI_USE_RESULT );
		}
		public function query_num_rows($sql){
			$result=$this->conn->query($sql);
			return $result->num_rows; 
		}

		public function update($sql){
			return  $this->conn->query($sql);
		}

	    	public function get_insert_id(){
                	$insertid= mysqli_insert_id ( $this->conn);//->insert_id;
            		return  $insertid; 
        	}   


		public static function getMyiface()
		{
			return new MysqlInterface("192.168.0.67", "xml", "xmlxml321", "") ;
  		}

		function __destruct()
		{
			return  $this->conn->close();
		}
	}
?>
