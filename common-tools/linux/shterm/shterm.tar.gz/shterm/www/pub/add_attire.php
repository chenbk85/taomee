<?php
	require_once("proto.php");
	require_once("comm.php");
	require_once("item.php");

	//$proto=new Cproto("192.168.0.23",21001 );
	$proto=new Cproto("10.1.1.5",21001 );
	//$proto=new Cproto($payserip , $payserport );
	/*
	for ($i=0; $i<80000;$i++ ){
		$retarr=$proto->user_get_nick(20066);
		//printf("%s:%d:%s\n", $userid,$retarr["result"] ,$retarr["sermsg"]);
	}
	*/
	foreach ( $item_list as  $attireid => $name  ){
		if ($attireid>160001 and $attireid<170001 ){
			echo $attireid ."\n";
			$proto->user_add_home_attire(4004204 ,$attireid ,1 );
		}
	}
?>
