<?php
define( "SUCC" ,							0	);
define( "FAIL" ,							-1	);
define( "DB_SUCC", 							0	);
define( "NO_DEFINE_ERR",   					1000);
//系统出错 一般是内存出错
define( "SYS_ERR",   						1001);

//数据库出错);
define( "DB_ERR",   						1002);

//"NET"出错);
define( "NET_ERR",   						1003);

//命令"ID"没有定义);
define( "CMDID_NODEFINE_ERR", 			  	1004);
//协议长度不符合);
define( "PROTO_LEN_ERR",  			 		1005);

//数值越界);
define( "VALUE_OUT_OF_RANGE_ERR", 	 		1006);

//要设置的flag和原有一致 );
define( "FLAY_ALREADY_SET_ERR", 	 		1007);

//数据不完整);
define( "VALUE_ISNOT_FULL_ERR", 	 		1008);
//枚举越界);
define( "ENUM_OUT_OF_RANGE_ERR", 	 		1009);

//登入时，检查用户名和密码出错);
define( "CHECK_PASSWD_ERR",   				1103);

//在insert，"USERID"已存在);
define( "USER_ID_EXISTED_ERR",  			1104);
//在select update, delect 时，"USERID"不存在);
define( "USER_ID_NOFIND_ERR",  				1105);

//用户的"EMAIL" 为空);
define( "USER_EMAIL_NO_EXISTED_ERR",		1106);

//用户没有激活);
define( "USER_NOT_ENABLED_ERR", 			1107);
define( "USER_IS_ENABLED_ERR", 				1108);


//列表中的"ID"  好友列表，黑名单);
define( "LIST_ID_EXISTED_ERR", 				1109);
define( "LIST_ID_NOFIND_ERR", 				1110);

//小屋装扮 数据不存在);
define( "USER_HOME_ATTIRE_ID_NOFIND_ERR",  	1111);

//小屋装扮数据更新不符  );
define( "USER_SET_HOME_ATTIRE_DATA_ERR",  	1112);

// "EMAIL" 已存在  );
define( "EMAIL_EXISTED_ERR", 				1301);
define( "EMAIL_NOFIND_ERR", 				1302);


//该用户游戏积分没有找到);
define( "GAME_SCORE_NOFIND_ERR",  			1401);
define( "GAME_SCORE_NONEED_SET_ERR", 		1402);

//define( for payser  );
define( "PAY_ATTITE_ID_NOFIND_ERR", 		2001);
define( "PAY_ATTITE_PAYTPYE_NODEFINE_ERR", 	2002);

//define( for serial );
define( "SERIAL_ID_NOFIND_ERR", 			2101);
define( "SERIAL_ID_IS_USED_ERR", 			2102);

// transid 不存在);
define( "TRANS_ID_EXISTED_ERR",				2104);
define( "TRANS_ID_NOFIND_ERR", 				2105);


//已经处于包月状态);
define( "IS_MONTHED_ERR", 					2106);
//不处于包月状态);
define( "IS_NOT_MONTHED_ERR", 				2107);

//对账标志核对出错);
define( "IS_NOT_VALIDATED_ERR", 			2108);
define( "IS_VALIDATED_ERR", 				2109);

//对账金额出错);
define( "VALIDATE_ERR", 					2110);
?>
