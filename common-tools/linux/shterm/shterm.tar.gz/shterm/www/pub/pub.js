function re_check(txt)
{
 if (confirm(txt)) {
  return true;
 } else {
  return false;
 }
}
