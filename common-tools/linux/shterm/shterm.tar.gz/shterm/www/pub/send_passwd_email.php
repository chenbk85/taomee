<?php

// the common loggic deal api
#require_once '../Common/Common.class.php' ;
require_once 'PEAR.php';
require_once "proto.php" ;
require_once "Mail.php";



class Crypt{

	private $securekey, $iv;
	function __construct($textkey="taomee") {

		$this->securekey = md5($textkey) ;
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$this->iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		    
	}
	function encryptData($value){
		$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $this->securekey, $value, MCRYPT_MODE_ECB, $this->iv);
		return $crypttext;
	}

	function decryptData($value){
		$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $this->securekey, $value, MCRYPT_MODE_ECB, $this->iv);
		return trim($decrypttext);
	}

}



class logic  extends Cproto{

	var $debug = 0;
	var $flag_string = "taomee" ;

	function logic($dbhost,$dbport){

		$this->__construct($dbhost,$dbport) ;
	}

	function __construct( $dbhost,$dbport){

		$this->sock = new socket($dbhost,$dbport);

	}

	/*
	 *
	 * get the newpasswd by userid or email ,the new passwd would send to user's mail box
	 *
	 */ 
	function getnewpwd($user){

		//1.auto generation a new passwd , 2.email    
		//1.
		//$userid ,$email ,$nick ;
		$text_pwd = substr(md5(time()),0,6) ;
		$md5_pwd = md5($text_pwd) ;
		$newpasswd = md5($text_pwd);
		if(ereg("@",$user)){
			//email type ,get the userid by email addr
			//echo "email type " ;
			print("LOGIC::getnewpwd email type") ;
			$uppack = $this->user_get_userid_by_email($user) ;
			$userid = $uppack['userid'] ;
			print("LOGIC::getnewpwd the email's  userid is $userid,and the result is ".$unpack['result']) ;
			//echo "userid = ".$userid ;
			if($userid == 0){
				//trigger_error("email addr not find!") ;
				return -1 ;
			}
			else if($userid == -1){
				//trigger_error("Net error!") ;
				return -1 ;
			}

		}
		//userid type
		else{
			$userid = $user ;
		}

		$unpacked = $this->userinfo_get_info_all($userid) ;
		if($unpacked){
			$nick = $unpacked["nick"] ;
			$email= $unpacked["email"] ;
			//$email = "newday.jesse@gmail.com" ;
			//echo "nick:$nick---email:$email" ;
		}

		if((!$userid) ||(!$nick) || (!$email)){

			//trigger_error("unknow error !") ;
			return	-1 ;

		}

		//right user ,get the encrypt url (activenum) 
		$crypter = new Crypt("taomee") ;  // the text_key = taomee 
		$txt = $this->flag_string.$userid.$md5_pwd ;
		print("the txt is ".$txt) ;
		$activenum = bin2hex($crypter->encryptData($txt)) ;
		//设置数据库获取新密码成功标志位
		$this->user_set_flag_change_passwd($userid) ;
		//2.mail 
		$from = "service@taomee.com" ;
		$subject = "获取新密码－摩尔庄园，快乐童年！" ;
                //$domain = C('DOMAIN') ;  //靠
                //$domain .= __APP__ ;
				$setpwdurl = "www.ccc.com";
				$link =  "$setpwdurl?userid=$userid&activenum=$activenum " ;
		$message = "

<html>
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
<style type=\"text/css\">
<!--
body,td,th {
	font-size: 14px;
	color: #333333;
	line-height:30px;
}
body {
	background-color: #FFFFFF;
	margin:10px;
	padding:0;
}
a:link {
	color: #333399;
}
a:visited {
	color: #333399;
}
a:hover {
	color: #FF3300;
}
a:active {
	color: #333399;
}
-->
</style></head>

<body>亲爱的<span style=\"color:#009933 \">$nick</span>：<br>
<br>
摩尔庄园公民管理处已经通过了你的重置密码申请。<br>
<ul>
	<li>你可以点击<a href=\"$link\" style=\"font-weight:bold; \">\"设置新密码\"</a>重置你的密码哦！
	</li>
	<li>你还可以点击以下连接进入重置密码页面：
	<br>
	<a href=\"$link\"  style=\"font-size:12px \">$link</a><br>
	（提示：如果这个链接点击无效，请拷贝粘贴到你浏览器的地址栏上）</li>
</ul>

*你在重置密码页面时会被要求输入注册码,你的注册码是：<span style=\"color:#FF6600; font-weight:bold; \">$text_pwd</span>（提示：请尝试粘贴或者复制）
<br>
<br>
<div style=\"text-align:left; \">祝你在摩尔乐园生活愉快哦!<br>
</div>
<br>
<div style=\"text-align:right;\">摩尔庄园公民管理处</div>
</body>
</html>
			
" ;
		$to = $email ;
		print("send email to".$to) ;
		if($this->emailHtml($from,$subject,$message,$to)) return -3;                     //发送邮件失败（系统繁忙！）

	}


	/*
	 *activate the newpasswd 
	 *
	 */

	function setyourpwd($userid,$register_num,$crypt_string,$newpwd){
		$bin = pack('H*', $crypt_string) ;
		$crypter = new Crypt("taomee") ;  // the text_key = taomee 
		$plaintxt = $crypter->decryptData($bin) ;
		print("after decrypt ,the txt is".$plaintxt) ;
		$flag = substr($plaintxt,0,strlen($this->flag_string)) ;
		$url_userid = substr($plaintxt,strlen($this->flag_string),strlen($userid)) ; 
		print("decrypt the userid=".$url_userid."the flag =".$flag) ;
		if(($flag == $this->flag_string) &&($userid == $url_userid)){
			//right url
			$verify = substr($plaintxt,strlen($this->flag_string)+ strlen($userid),32) ; // md5 
			print("LOGIC:setyourpwd :the verify num is $verify,and the register_num = $register_num") ;
			if(md5($register_num) != $verify){
				//注册码是否正确
				return -1 ; //  错误的注册码

			}
			else{

			//echo "userid:"$userid."passwd".$newpwd ;
			$result =  $this->user_change_passwd_without_check($userid,$newpwd) ;
			return $result['result'] ;

			}

		}
		else
			return -1 ;

	}


	function emailHtml($from, $subject, $message, $to) {
		//$host = "taomee.com";
		$host = "localhost";
		//$username = "jesse";
		//$password = "jesuschrist";
		$headers = array ('MIME-Version' => "1.0", 'Content-type' => "text/html; charset=UTF-8;", 'From' => $from, 'To' => $to, 'Subject' => $subject);

		$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => false));
		$mail = $smtp->send($to, $headers, $message);
		if (PEAR::isError($mail))
			return -1;
		else
			return 0;
	}
}


?>
