<?php
//	require_once("proto.php");
	require_once("proto.php");
    //$proto=new Cproto("10.1.1.7",36001);
    //$proto=new Cproto("10.1.1.4",4431);
   //print_r( $proto->user_login(88693,1,1));

    //print_r( $proto->pp_set_vip(5000333,1,1));
	//$proto=new Cproto("10.1.1.7",36001);
	//$proto=new Cproto("10.1.1.4",4431);
	//$proto=new Cproto("10.1.1.5",16001);
	//$proto=new Cproto("116.228.240.106",16001);
	//print_r( $proto->pp_set_vip(5000333,1,1));
	//print_r($proto->user_get_auto_list(50026));
	//print_r($proto->user_farm_get_web(50026));
	$proto=new Cproto("10.1.1.7",11001);
    //$proto=new Cproto("114.80.98.21",21002);
	print_r($proto->history_ip_record(50000,0,1));
	//print_r($proto->user_egg_get_all_web(50100));
 //   $proto=new Cproto("192.168.61.98",31002);
//	print_r($proto->ud_get_pic_server_list());
			
?>
