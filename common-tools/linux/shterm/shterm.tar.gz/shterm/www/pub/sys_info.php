<?php
	$ud_ip="192.168.61.98";
	$ud_port="31002";
	#数据目录
	$data_dir="/home";
	
	#监控机器的外网ip的网卡
	$post_eth="eth0";

	function get_cmd_return($cmd){
		$fp= popen  ( $cmd ,"r" );
		$buf=fread($fp,2048);
		fclose($fp);
		return $buf;
	}
	$cmd="awk '{print $1}' /proc/loadavg";
	$sys_load=get_cmd_return($cmd);
	print $sys_load;

	$cmd="df $data_dir |grep $data_dir  | awk '{print $4}'";
	$disk_free=get_cmd_return($cmd);
	print $disk_free;

	$cmd="/sbin/ifconfig $post_eth | awk '$1==\"inet\"{print $2}' | awk -F: '{print $2}'";
	$ip=get_cmd_return($cmd);

	print $ip;
	print ip2long( $ip);
	print long2ip(ip2long( $ip) );

	require_once("proto.php");
	$proto=new Cproto($ud_ip,$ud_port );
	print_r ($proto->ud_report_pic_server_info(ip2long($ip), $sys_load,$disk_free,0 ));

?>
