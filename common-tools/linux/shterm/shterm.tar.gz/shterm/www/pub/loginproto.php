<?php

function hex2bin($hexdata) {
    $bindata = '';
    for($i=0; $i < strlen($hexdata); $i += 2) {
        $bindata .= chr(hexdec(substr($hexdata, $i, 2)));
    }
    return $bindata;
}

class socket{
	//private:
	var $socket; //socket 句柄
	//var $debug = 1;
	function __construct( $payserip,$payserport){
		$address = gethostbyname($payserip );
		if (($this->socket = socket_create(AF_INET,SOCK_STREAM,SOL_TCP))< 0 )
		{
			trigger_error("Couldn't create socket: " . socket_strerror(socket_last_error()) . "\n");
		}	
		socket_connect($this->socket,$address,$payserport );
	}
	function sendmsg($msg){
		socket_write($this->socket,$msg, strlen($msg) );
		$buf= socket_read($this->socket,4096);
		$pkg_arr=@unpack("Nproto_len",$buf);
		$proto_len= $pkg_arr["proto_len"];
		//echo $proto_len;
		while ($proto_len!=strlen($buf) ){
			$buf .=	socket_read($this->socket,4096);
		}	
		//echo (bin2hex($buf))."<br>";
		return $buf;
	}
	function close(){
		socket_close($this->socket);
	}

	function __destruct(){
	}
} 

class Cloginproto{
	var $sock; 
	function __construct( $payserip,$payserport){
		$this->sock = new socket($payserip,$payserport);
	}
	function __destruct(){
		if ($this->sock) $this->sock->close(); 
	}

	function park_dirser($cmdid,$userid,$private_msg){
		//18：报文头部长度
		$pkg_len=17+strlen($private_msg) ;
		$result=0;
		return pack("NCNNN",$pkg_len,1,$cmdid,$userid,$result)
			.$private_msg;
	}
	function park($cmdid,$userid,$private_msg){
		//18：报文头部长度
		$pkg_len=17+strlen($private_msg) ;
		$result=0;
		return pack("NANNN",$pkg_len,1,$cmdid,$userid,$result)
			.$private_msg;
	}

	function unpark($sockpkg, $private_fmt){
		$pkg_arr=@unpack("Nproto_len/A1version/Ncommandid/Nuserid/Nresult/",$sockpkg);
		if ($private_fmt!="" && $pkg_arr["result"]==0){//成功
		$pkg_arr=@unpack("Nproto_len/A1version/Ncommandid/Nuserid/Nresult/".$private_fmt, $sockpkg);
		}	 
		return $pkg_arr;
	}


	function user_enabled ($userid, $enabled_sign ){
		$pri_msg=pack("A48",$enabled_sign  );
		$sendbuf=$this->park(2 ,$userid, $pri_msg);
		return $this->unpark($this->sock->sendmsg($sendbuf),"");
	}

	function register($nick,$passwd,$email ){
		$pri_msg=pack("A16A16LA64",$nick ,$passwd,rand(),$email );
		$sendbuf=$this->park(1 ,$userid, $pri_msg);
		return $this->unpark($this->sock->sendmsg($sendbuf),"Luserid");
	}

	function get_servserid_by_userid($userid ){
		$sendbuf=$this->park_dirser(30001 ,$userid, "" );

		$fmt="Nserverid/a16name/Ncount/a16serverip".
				"/nserverport/Nfriendcount";
		return $this->unpark($this->sock->sendmsg($sendbuf),$fmt);
	}

	function get_online_serverlist(){
		$pri_msg=pack("N",0 );
		$sendbuf=$this->park_dirser(102 ,0 , $pri_msg );
		$recvbuf=$this->sock->sendmsg($sendbuf);	
		$fmt="Ncount";
		$recvarr=$this->unpark($recvbuf,$fmt );		
		echo "===". $recvarr["result"]."===11";  
		if ($recvarr && $recvarr["result"]!=0){
			return $recvarr;
		}

		//SUCC
		$recv_count=$recvarr["count"];
		for ($i=0;$i<$recv_count;$i++){
			$fmt=$fmt . "/Nserverid_$i/a16name_$i/Ncount_$i/a16serverip_$i".
				"/nserverport_$i/Nfriendcount_$i"  ;
		}
		return $this->unpark($recvbuf, $fmt );
	}
} 

//日志消息
function	dbg_log($word){ 
	global $logfile;
	$fp = fopen($logfile, "a");	
	flock($fp, LOCK_EX) ;
	fwrite($fp,strftime("%Y%m%d%H%I%S",time()).":".$word."\t\n");
	flock($fp, LOCK_UN); 
	fclose($fp);
}

?>
