<?php
	function gen_npc_pkgbody($xmlstr)
	{
		$doc = new DOMDocument();
		$doc->loadXML($xmlstr);

		$pkg = '';
		traverse_elems($doc, 'NPC', 'parse_npc_tag', &$pkg);
		$pkg = $pkg.pack('S', $doc->getElementsByTagName('CMD')->length);
		traverse_elems($doc, 'CMD', 'parse_cmd_tag', &$pkg);
		return $pkg;
	}

	function parse_npc_tag($elem, $pkg)
	{
		$nick  = $elem->getAttribute("Nick");
		$color = $elem->getAttribute("Color");
		$dress = $elem->getAttribute("Dress");
		$dressids = split(';', $dress);
		$cnt   = count($dressids);
		if ( ($cnt == 1) && (trim($dressids[0]) == '') ) {
			$cnt = 0;
		}
		$pkg   = $pkg.pack('a16LC', $nick, $color, $cnt);
		for ($i = 0; $i != $cnt; ++$i) {
			$pkg = $pkg.pack('L', $dressids[$i]);
		}
	}

	function parse_cmd_tag($elem, $pkg)
	{
		define('ENTER_MAP', 1);
		define('LEAVE_MAP', 2);
		define('TAKE_ACTION', 3);
		define('WALK', 4);
		define('TALK', 5);
		define('XFORM_OTHERS', 99999999);
		define('DESTROY_NPC', 100000000);

		$type  = $elem->getAttribute("CmdType");
		$delay = $elem->getAttribute("Delay");
		$parms = split(';', $elem->getAttribute("Params"));
		$pkg   = $pkg.pack('LL', $type, $delay);

		switch ($type) {
		case ENTER_MAP:
			$pkg = $pkg.pack('LL', $parms[0], $parms[1]);
			break;
		//case LEAVE_MAP:
		//	break;
		case TAKE_ACTION:
			$pkg = $pkg.pack('LC', $parms[0], $parms[1]);
			break;
		case WALK:
			$pkg = $pkg.pack('SS', $parms[0], $parms[1]);
			break;
		case TALK:
			$pkg = $pkg.pack('Sa*', strlen($parms[0]), $parms[0]);
			break;
		case XFORM_OTHERS:
			$pkg = $pkg.pack('LLL', $parms[0], $parms[1], $parms[2]);
			break;
		//case DESTROY_NPC:
		//	break;
		default:
			break;
		}

	}

	function traverse_elems($doc, $tagname, $proc_func, $func_arg)
	{
		$elems = $doc->getElementsByTagName($tagname);
		foreach ( $elems as $elem ) {
			$proc_func($elem, &$func_arg);
		}
	}

	// here is an example
	//$xmlstr = '<NPC Nick="小二" Color="367" Dress="12001; 12002" >'.
			//'<CMD CmdType="1" Params="0; 1" Delay="1" />'.
			//'<CMD CmdType="3" Params="2; 0" Delay="1" />'.
			//'<CMD CmdType="4" Params="200; 150" Delay="5" />'.
			//'<CMD CmdType="5" Params="小样，您点啥菜啊？要二两酒不？" Delay="3" />'.
			//'<CMD CmdType="2" Params="" Delay="3" />'.
			//'<CMD CmdType="100000000" Params="" Delay="60" />'.
		  //'</NPC>';

	//$dd = gen_npc_pkgbody($xmlstr);
	//echo 'pkg: '.$dd.'<br/>size: '.strlen($dd).'<br/>';
?>
