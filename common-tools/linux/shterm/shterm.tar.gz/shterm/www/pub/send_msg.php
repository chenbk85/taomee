<?php

	require_once("proto.php");
	//require_once("send_passwd_email.php");

#	$proto=new Cproto("192.168.0.23",21001 );
	$proto=new Cproto("10.1.1.5",21001 );
	$bruce=fopen("allvip.txt","r");
	if(!$bruce)
	{
	    echo'文件不存在';
	    exit;
	}
	$i=0;
	while (!feof($bruce))
	{
	    $userid=fgets($bruce);
		$proto->emailsys_add_email($userid,1000054,0,"克劳神父", "亲爱的小摩尔，3月27日~4月9日，和超级拉姆一起探索大榕树的秘密世界吧！");

#$proto->emailsys_add_email($userid,1000054,0,"",
#			"亲爱的小摩尔，我的阿福号已经重建完成，欢迎你带着你的超级拉姆一起来参加“功夫派对”！");
		$i++;
		if($i%100==0){
			print "done". $i ."\n";
		}
	}
	fclose($bruce);
?>

