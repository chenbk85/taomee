<?php

	require_once("config.php");

//	error_reporting(0);

	define( "REASON_SU" ,							1	);
	define( "REASON_WRITING" ,						2	);
	define( "REASON_MSGBOARD" ,						3	);
	define( "ATTR_XIAOMEE" ,						1005);

	$g_game_flag[1]="摩尔庄园";
	$g_game_flag[2]="派派";
	$g_game_flag[3]="大玩园";

	$g_profession_def[0]=array("向导",7);
	$g_profession_def[1]=array("警查",2);
	$g_profession_def[2]=array("记者",2);
	$g_profession_def[3]=array("骑士",4);
	$g_profession_def[4]=array("消防员",2);
	$g_profession_def[5]=array("医师",2);

	

	
	$g_petcolor[1]="红色";
	$g_petcolor[2]="黄色";
	$g_petcolor[3]="天蓝色";
	$g_petcolor[4]="粉红色";
	$g_petcolor[5]="橘黄色";
	$g_petcolor[6]="灰色";
	$g_petcolor[7]="黑色";
	$g_petcolor[8]="紫色";
	$g_petcolor[9]="土色";
	$g_petcolor[10]="绿色";

	$g_task_flag[0]="<font color=red>未接</font>";
	$g_task_flag[1]="<font color=blue>己接</font>";
	$g_task_flag[2]="<font color=green>己完成</font>";
	$g_task_flag[3]="<B>数据错误</B>";
	$user_task_list[]=array(0,"我想成为摩尔庄园向导" );
	$user_task_list[]=array(8,"我想成为摩尔庄园警官" );
	$user_task_list[]=array(16,"我想成为摩尔庄园记者" );
	$user_task_list[]=array(17,"我想成为摩尔庄园记者" );
	$user_task_list[]=array(131,"消防员" );
	$user_task_list[]=array(24,"摩尔庄园新公民入住手续" );
	$user_task_list[]=array(25,"阳光小丫" );
	$user_task_list[]=array(26,"投中靶心" );
	$user_task_list[]=array(27,"雪山上的雪人" );
	$user_task_list[]=array(28,"环保小床" );
	$user_task_list[]=array(29,"机器人拼装" );
	$user_task_list[]=array(30,"暂时站位的" );
	$user_task_list[]=array(31,"染料任务" );
	$user_task_list[]=array(32,"制作红旗" );
	$user_task_list[]=array(48,"兑换怪怪装" );
	$user_task_list[]=array(49,"南瓜灯" );
	$user_task_list[]=array(50,"怪兽线索收集" );
	$user_task_list[]=array(171,"隐身衣" );
	$user_task_list[]=array(51,"圣诞树" );
	$user_task_list[]=array(52,"锦囊" );
	$user_task_list[]=array(53,"送福" );
	$user_task_list[]=array(54,"龙珠任务" );
	$user_task_list[]=array(55,"拉姆跑步" );
	$user_task_list[]=array(56,"妇女节" );
	$user_task_list[]=array(61,"么么公主卡片任务" );
	$user_task_list[]=array(62,"馒头任务" );
	$user_task_list[]=array(172,"黑猫 炫彩星" );
	$user_task_list[]=array(151,"见习骑士" );
	$user_task_list[]=array(152,"勋章骑士" );
	$user_task_list[]=array(69,"带小小毛毛头参观庄园" );
	$user_task_list[]=array(63,"拿毛毛头翻译头套" );
	$user_task_list[]=array(66,"魔术师" );
	$user_task_list[]=array(67,"找回菩提大伯" );
	$user_task_list[]=array(68,"准备进入黑森林" );
	$user_task_list[]=array(70,"拯救千年榕树" );
	$user_task_list[]=array(161,"医师" );
	$user_task_list[]=array(72,"火神杯" );
	$user_task_list[]=array(74,"火炬" );
	$user_task_list[]=array(174,"友谊之花" );
	$user_task_list[]=array(75,"火神杯领奖" );
	$user_task_list[]=array(76,"魔法拉姆日记本" );
	$user_task_list[]=array(77,"小裁缝" );
	$user_task_list[]=array(78,"小老师" );
	$user_task_list[]=array(79,"摩尔王" );
	$user_task_list[]=array(80,"天外来客" );
	$user_task_list[]=array(81,"拉姆王印迹" );
	

	//渠道
	$post_cfg[0]=array ("51mole","red" );
    $post_cfg[1]=array ("92game","blue" );
    $post_cfg[2]=array ("766","green" );
    $post_cfg[3]=array ("QQ空间","brown" );
    $post_cfg[4]=array ("7K7K","purple" );
    $post_cfg[5]=array ("4399","#2E5855" );
    $post_cfg[6]=array ("3839","#554110" );
    $post_cfg[7]=array ("2144","#1B1652" );
    $post_cfg[8]=array ("小游戏","#90EE90" );
    $post_cfg[9]=array ("唤醒","#FFA500" );
    $post_cfg[10]=array ("向导","#7F7F7F" );
    $post_cfg[11]=array ("QQ礼活动","#4E0E55" );
    $post_cfg[12]=array ("摩尔大使","#E8643A" );
    $post_cfg[13]=array ("QQmini","#1B1652" );
    $post_cfg[14]=array ("4399xyx","#FFA500" );
    $post_cfg[15]=array ("cks","purple" );
    $post_cfg[16]=array ("yx007","black" );
    $post_cfg[17]=array ("新浪","black" );
    $post_cfg[18]=array ("宏梦","black" );
    $post_cfg[19]=array ("19","black" );
    $post_cfg[20]=array ("彩虹堂","black" );
    $post_cfg[21]=array ("gameyes","black" );
    $post_cfg[22]=array ("游戏22","black" );
    $post_cfg[23]=array ("41717小游戏","black" );
    $post_cfg[24]=array ("f1212","black" );
    $post_cfg[25]=array ("游戏82","black" );
    $post_cfg[26]=array ("翼动小游戏","black" );
    $post_cfg[27]=array ("成都小游戏网","black" );
    $post_cfg[28]=array ("92小游戏","black" );
    $post_cfg[29]=array ("29","black" );
 	$post_cfg[30]=array ("30","black" );
    $post_cfg[31]=array ("31","black" );
    $post_cfg[32]=array ("32","black" );
    $post_cfg[33]=array ("33","black" );
    $post_cfg[34]=array ("34","black" );
    $post_cfg[35]=array ("35","black" );
    $post_cfg[36]=array ("36","black" );
    $post_cfg[37]=array ("37","black" );
    $post_cfg[38]=array ("38","black" );
    $post_cfg[39]=array ("39","black" );



	//投稿类型定义
	$writing_type_cfg[1001]=array(1001,"游戏咨询类",1);
	$writing_type_cfg[1002]=array(1002,"BUG意见类",1);
	$writing_type_cfg[1003]=array(1003,"儿童生活类",1);
	$writing_type_cfg[1004]=array(1004,"时报投稿类",1);
	$writing_type_cfg[1005]=array(1005,"会员回复类",1);
//	$writing_type_cfg[1006]=array(1006,"英语故事",1);
	$writing_type_cfg[1007]=array(1007,"爱心蘑菇",1);
	$writing_type_cfg[1008]=array(1008,"收集箱",1);
	$writing_type_cfg[1009]=array(1009,"其它分类",1);
	$writing_type_cfg[2001]=array(2001,"(会员)游戏咨询类",1);
	$writing_type_cfg[2002]=array(2002,"(会员)BUG意见类",1);
	$writing_type_cfg[2003]=array(2003,"(会员)儿童生活类",1);
	$writing_type_cfg[2004]=array(2004,"(会员)时报投稿类",1);



	$writing_type_cfg[1010]=array(1010,"周边产品类",2);
	$writing_type_cfg[1011]=array(1011,"十佳向导类",2);
	$writing_type_cfg[1012]=array(1012,"调查类",2);
	$writing_type_cfg[1013]=array(1013,"许愿调查",2);
//	$writing_type_cfg[1014]=array(1014,"十佳警察",2);
	$writing_type_cfg[1015]=array(1015,"大脑操",2);
	$writing_type_cfg[1016]=array(1016,"智慧星",2);
	$writing_type_cfg[1017]=array(1017,"生日许愿",2);
	$writing_type_cfg[1018]=array(1018,"圣诞许愿",2);
	$writing_type_cfg[1029]=array(1029,"小剧本",2);
	$writing_type_cfg[1020]=array(1020,"捐款用法",2);

	//week cnf
	$week_conf[0]= array("周一");
	$week_conf[1]= array("周二");
	$week_conf[2]= array("周三");
	$week_conf[3]= array("周四");
	$week_conf[4]= array("周五");
	$week_conf[5]= array("周六");
	$week_conf[6]= array("周日");
	//举报类型
	$reasonmap[1]=  "名字不文明";
	$reasonmap[2]=  "说话不文明";
	$reasonmap[3]=  "索要个人隐私";
	$reasonmap[4]=  "使用外挂";

	//处理方式 
	$actionlist[0]="强制24小时离线";
	$actionlist[1]="封号";

	$g_task_month_flag[0]="领工资";
	
	
	//权限标志
	$flag_list[0]=array(0x00000001,"power_flag_read", "基本数据查看." );
	$flag_list[1]=array(0x00000002,"power_flag_send_user_msg", "回复用户　　." );
	$flag_list[2]=array(0x00000004,"power_flag_change_user", "修改用户数据." );
	$flag_list[3]=array(0x00000008,"power_flag_send_group_msg", "群发在线信息." );
	$flag_list[4]=array(0x00000010,"power_flag_change_admin", "权限管理　　." );
	$flag_list[5]=array(0x00000020,"power_flag_game_score_clean", "清空游戏列表." );

	$gamemap[0]=array(0,"所有" ,false);
    $gamemap[1]=array(1,"消消乐" ,true);
    $gamemap[2]=array(2,"滑雪" ,true);
    $gamemap[4]=array(4,"五子棋" ,false);
    $gamemap[5]=array(5,"赛车" ,true);
    $gamemap[8]=array(8,"钓鱼" ,true);
    $gamemap[9]=array(9,"滑冰" ,true);
     $gamemap[13]=array(13,"象棋" ,false);
     $gamemap[14]=array(14,"拼图" ,true);
     $gamemap[15]=array(15,"足球" ,true);
     $gamemap[16]=array(16,"泡泡龙(单人)" ,true);
     $gamemap[17]=array(17,"泡泡龙(双人)" ,false);
     $gamemap[19]=array(19,"小农夫" ,true);
     $gamemap[20]=array(20,"摘果子" ,true);
     $gamemap[24]=array(24,"萤火虫" ,true);
     $gamemap[25]=array(25,"骑猪" ,true,"25");
     $gamemap[21]=array(21,"激流勇进" ,true,"21");
     $gamemap[26]=array(26,"射击" ,true,"26");
     $gamemap[27]=array(27,"跳水" ,true,"27");
 	$gamemap[31]=array(31,"鱼" ,true,"31");
 	$gamemap[33]=array(33,"方块" ,true,"33");
 	$gamemap[35]=array(35,"R4" ,true,"35");
 	$gamemap[36]=array(36,"连连看" ,true,"36");
     $gamemap[18]=array(18,"救人质" ,true,"18");
 	$gamemap[37]=array(37,"钢琴" ,true,"37");
 	$gamemap[42]=array(42,"餐厅打工" ,true,"42");
 	$gamemap[41]=array(41,"找ca" ,true,"41");
 	$gamemap[43]=array(43,"海底寻宝" ,true,"43");
 	$gamemap[46]=array(46,"零花钱大作战" ,true,"46");
 	$gamemap[47]=array(47,"冰淇淋" ,true,"47");
 	$gamemap[48]=array(48,"消防员" ,true,"48");
 	$gamemap[49]=array(49,"快乐拼盘" ,true,"49");
 	$gamemap[55]=array(55,"阳光运工" ,true,"55");
 	$gamemap[56]=array(56,"拉姆救治游戏" ,true,"56");
 	$gamemap[59]=array(59,"摩尔爱跳舞" ,true,"59");
 	$gamemap[60]=array(60,"修剪草坪" ,true,"60");

//-------------------------------------PP---------------------------------------



	$logfile="/tmp/su_opt_".date(Ymd).".log" ;

	function get_std_page(){
		echo " 
			<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 
				'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
			<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
			<head>
			<link id='themestyle' rel='stylesheet' type='text/css' href='./css.css'>
			</head>
			<body>
			</body>
			</html>
			";
	}
	function login_check(){
		global  $_SESSION; 
		$loginflag= $_SESSION["loginflag"];
		if (!$loginflag){//未登入
			echo " 
			<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 
				'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
			<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
			<head>
			<link id='themestyle' rel='stylesheet' type='text/css' href='./css.css'>
			</head>
			<body>
			<div id='wrap' >
			<div align=center><font color=red size=4> 尚未登入 </font><div> 
			</div>
			</body>
			</html>
			";
			return false;		
		}else{
			return true;
		}
	}

	function admin_check($value){
		global  $_SESSION; 
		return  $_SESSION[$value];
	}

	function  get_flag($value){
		if ($value>0)	return "<font color=green>是</font>";
		else	return "<font color=red>否</font>";
	}	
	
 	function GetNextdate($datetime){
                $monthday=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                $year=substr($datetime,0,4)*1;
                $month=substr($datetime,4,2)*1;
                $day=substr($datetime,6,2)*1;
                $day++;

                if ($day> $monthday[$month]){
                        $day-=$monthday[$month];
                        $month++;
                        if ($month>12 ) {
                                $month-=12;
                                $year++;
                        }

                }
                return  $year*10000 + $month*100 + $day;
    }

	function GetPrevdate($datetime){
                $monthday=array(0,31,28,31,30,31,30,31,31,30,31,30,31);
                $year=substr($datetime,0,4)*1;
                $month=substr($datetime,4,2)*1;
                $day=substr($datetime,6,2)*1;
                $day--;

                if ($day==0 ){
                        $month--;
                        if ($month ==0) {
                                $month=12;
                                $year--;
                        }
                        $day=$monthday[$month];

                }
                return  $year*10000 + $month*100 + $day;
        }
        function GetPredate(){
                global   $HTTP_SESSION_VARS;
                if ($HTTP_SESSION_VARS["startdate"] !="" )
                        return $HTTP_SESSION_VARS["startdate"] ;
                else return date("Ymd");
        }
		function reset_input(){
        echo "<script language=javascript>window.parent.frames['head_frm'].location.reload();</script>";
    	};
		function get_selected($value,$pre_value){
			if ($value==$pre_value)
				echo " selected ";
		}	
		function get_selected_str($value,$pre_value){
			if ($value==$pre_value)
				return " selected ";
			else return "";
		}
	function get_checked_str($value,$pre_value){
			if ($value==$pre_value)
				return "checked ";
			else return "";
		}

function get_date_from_time_t( $value ){
		 return date ("Y-m-d H:i:s", $value);
}
function get_time_from_time_t( $value ){
		 return date ("H:i:s", $value);
}
function get_week_str( $value ){
	global $week_conf;
	if ($value==0 ){
		return "每天";
	}else{
		return $week_conf[$value-1][0];
	}

}
function Caldate($datetime,$daycounts){
        $year=substr($datetime,0,4)*1;
        $month=substr($datetime,4,2)*1;
        $day=substr($datetime,6,2)*1;
        $t= mktime(0,0,0,$month ,$day, $year);
        $t+=$daycounts*24*3600;
        return date ("Ymd", $t);
}


//日志消息
function	dbg_log($word){ 
	global $logfile;
	$fp = fopen($logfile, "a");	
	flock($fp, LOCK_EX) ;
	fwrite($fp,strftime("%Y%m%d%H%I%S",time()).":".$word."\n");
	flock($fp, LOCK_UN); 
	fclose($fp);
}
function	get_std_str($word,$count=5){ 
	$result="";
	for ($i=strlen($word);$i<$count;$i++  )	
		$result = $result .  "&nbsp;&nbsp;";
	return $result . $word;
}
function	get_time_ex($time, $set_0_flag=false){ 
	 
	if ($time<1000){
		if ($time==0){
			if ( $set_0_flag==false){
				return $time;
			}else{
				return time(NULL)+$time*3600; 
			}
		}

		return time(NULL)+$time*3600; 
	}else{
		return $time;
	}

}
function	get_hex($valuelist,$len){ 
	for ( $j=0;$j<$len;$j++  ) {
		$valuemsg.=sprintf  ( "%02X", ord($valuelist[$j]) );
	}
	return $valuemsg;
}
function	get_arr_fmt_str($arr,$split=","){ 
	if (! is_array($arr) ) return "";
	$var="";
	foreach($arr as $item){
		$var.=$item.$split;
	}
	return substr($var,0,strlen($var)-1 );
}

?>

