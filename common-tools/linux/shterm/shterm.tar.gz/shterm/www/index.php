<?php
	$adminid= 	$_SESSION["adminid"];
	$nick= 	$_SESSION["nick"];
	$loginflag= $_SESSION["loginflag"];

	if ($loginflag==true)  $sub_frm="./show.php"; 
	else  $sub_frm="./login/login.php"  ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>客服修正</title>
</head>
<frameset cols="150,* "   frameborder=0 >
	<frame name="menu_frm"  scrolling="no" src="./menu.php" >
	<frame name="sub_frm"  scrolling="yes" src="<?php echo $sub_frm;?>"   >
</frameset>
</html>
