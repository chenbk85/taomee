#!/bin/sh
sudo /usr/bin/killall -9 Flashpolicyd
sleep 1
sudo /opt/taomee/monster/flashpolicyd/Flashpolicyd /opt/taomee/monster/flashpolicyd/bench.conf
			
